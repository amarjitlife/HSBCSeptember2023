
//____________________________________________________

interface Superpower {
	fun fly()
	fun saveWorld()
}

//____________________________________________________

class Spiderman : Superpower {
	override fun fly() 		{ println("Fly Like Spiderman!") }
	override fun saveWorld() { println("Save World Like Spiderman!") }
}

class Superman : Superpower {
	override fun fly() 		{ println("Fly Like Superman!") }
	override fun saveWorld() { println("Save World Like Superman!") }
}

class Heman : Superpower {
	override fun fly() 		{ println("Fly Like Heman!") }
	override fun saveWorld() { println("Save World Like Heman!") }
}

class HanumanJi : Superpower {
	override fun fly() 		{ println("Fly Like HanumanJi!") }
	override fun saveWorld() { println("Save World Like HanumanJi!") }
}

open class Wonderwoman {
	open fun fly() 		{ println("Fly Like Wonderwoman!") }
	open fun saveWorld() { println("Save World Like Wonderwoman!") }
}

//____________________________________________________
// Using Inheritance

// class Human {
// class Human : Spiderman() {
// class Human : Superman() {
// class Human : Heman() {
class Human : Wonderwoman() {
	override fun fly() 		{ super.fly() 		}	 //{ println("Fly Like Human!") }
	override fun saveWorld(){ super.saveWorld() }	 //{ println("Save World Like Human!") }
}

//____________________________________________________
// Using Composition

class HumanAgain {
	// var power = Spiderman()
	// var power = Superman()
	var power = Heman()
	fun fly() 		{ power.fly() 		}	 //{ println("Fly Like Human!") }
	fun saveWorld() { power.saveWorld() }	 //{ println("Save World Like Human!") }
}

//____________________________________________________
// Using Composition

/// Polymorphic
class HumanBetter {
	// var power = Spiderman()
	// var power = Superman()
	var power: Superpower? = null
	fun fly() 		{ power?.fly() 		}	 //{ println("Fly Like Human!") }
	fun saveWorld() { power?.saveWorld() }	 //{ println("Save World Like Human!") }
}

//____________________________________________________

fun playWithHuman() {
	val h = Human()
	h.fly()
	h.saveWorld()

	val spider = Spiderman()
	spider.fly()
	spider.saveWorld()

	val ha = HumanAgain()
	// ha.power = Spideman()
	ha.fly()
	ha.saveWorld()

	val hb = HumanBetter()
	hb.power = Spiderman()
	hb.fly()
	hb.saveWorld()

	hb.power = Superman()
	hb.fly()
	hb.saveWorld()

	hb.power = Heman()
	hb.fly()
	hb.saveWorld()

	hb.power = HanumanJi()
	hb.fly()
	hb.saveWorld()
}

fun main() {
	playWithHuman()
}

