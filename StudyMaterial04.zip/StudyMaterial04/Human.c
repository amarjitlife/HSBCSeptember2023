#include <stdio.h>

typedef struct human_type {
	int id;
	char name[100];
	void (*dance)();
} Human;

void doBhangra() { printf("\nOyeee Hoyeee!!! Balleee Balleee"); }
void doLavani() { printf("\nDoing Maharastrian Folk Dance... Lavani Lavani!!!"); }

int main() {
	// struct human_type gabbar = { 420, "Gabbar Singh" };
	// Human gabbar = { 420, "Gabbar Singh" };

	Human gabbar = { 420, "Gabbar Singh", doBhangra };
	printf("\nID 	: %d", gabbar.id );
	printf("\nName 	: %s", gabbar.name );
	gabbar.dance();

	printf("\n");

	// struct human_type basanti = { 100, "Basanti Only" };
	Human basanti = { 100, "Basanti Only", doLavani };
	printf("\nID 	: %d", basanti.id );
	printf("\nName 	: %s", basanti.name );
	basanti.dance();
}

