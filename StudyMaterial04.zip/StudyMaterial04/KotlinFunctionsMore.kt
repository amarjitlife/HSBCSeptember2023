/*
Ccmpiling Kotlin File
kotlinc KotlinFunctionsMore.kt -include-runtime -d functionsMore.jar

Running Jar File
java -jar functionsMore.jar
*/

// __________________________________________________
// DO FOLLOWING CODE! MOMENT DONE RAISE YOUR HANDS!!!

// Function Type
//		(Int, Int) -> Int i.e. Function Taking Two Int and Returning Int 
fun sum( x: Int, y: Int ) : Int = x + y
fun sub( x: Int, y: Int ) : Int = x - y
fun mul( x: Int, y: Int ) : Int = x * y

fun sum3( x: Int, y: Int, z: Int ) : Int = x + y + z

// Higher Order Function
//		Functions Which Takes Function As Arguments
//				AND/OR
//		Returns Function
//		e.g. Following calculator Is Higher Order Function

// Polymorphic Function
//		Mechanism: By Passing Behaviour To Behviour
// Function Type
//		(Int, Int, (Int, Int)-> Int ) -> Int
fun calculator( x: Int, y: Int, operation: (Int, Int) -> Int ) : Int {
	return operation( x, y )
}

// val someValue = ::calculator

fun playWithCalculator() {
	val a = 300
	val b = 100
	var result: Int

	result = calculator(a, b, ::sum )
	println("Result : $result")

	result = calculator(a, b, ::sub )
	println("Result : $result")

	result = calculator(a, b, ::mul )
	println("Result : $result")
					// Lambda Expression
	val sumLambda = { x: Int, y: Int -> x + y }
	result = calculator(a, b, sumLambda )
	println("Result : $result")

	val sumLambdaAgain: (Int, Int) -> Int = { x: Int, y: Int -> x + y }
	result = calculator(a, b, sumLambdaAgain )
	println("Result : $result")

	result = calculator(a, b,  { x: Int, y: Int -> x + y } )
	println("Result : $result")

	val subLambda = { x: Int, y: Int -> x - y }
	result = calculator(a, b, subLambda )
	println("Result : $result")

	// error: type mismatch: inferred type is KFunction2<Int, Int, Int> but Int was expected
	// val something: Int = ::sum
	var something = ::sum // ::sum Is Reference To Function sum
	result = something(10, 20)
	println("Result : $result")

	// error: type mismatch: inferred type is KFunction3<Int, Int, Int, Int> 
	// but KFunction2<Int, Int, Int> was expected
	// something = ::sum3
	val somethingAgain: (Int, Int) -> Int= ::sum
	result = somethingAgain(10, 20)
	println("Result : $result")

	val someValue: (Int, Int, (Int, Int) -> Int ) -> Int  = ::calculator
	result = someValue( 111, 222, ::sum )
	println("Result : $result")
}

// __________________________________________________
// COMPLETE HANDS ON! MOMENT DONE RAISE YOUR FLAGS!!!

data class Person( val name: String, val profile: String, val title: String)

/*
// Following Both Codes Are Same! 
//		i.e. By Default Return Type Of Function Is Unit
//			  and Return Value Is Unit Of Unit Type
fun helloWorld() {
	// error: type mismatch: inferred type is String but Unit was expected
	return "Good Morning!"
}

fun helloWorldAgain() : Unit {
	// error: type mismatch: inferred type is String but Unit was expected
	return "Good Morning!"
}
*/

fun helloWorld() : String {
	// error: type mismatch: inferred type is String but Unit was expected
	return "Good Morning!"
}

// Return Value Is kotlin.Unit Of kotlin.Unit Type
fun helloWorldAgain() {

}

fun playWithFunctionAndLambdas() {
	println( helloWorld() )
	println( helloWorldAgain() )

	val something: (Int) -> Unit = { x: Int -> println( x ) }
	val result1: Unit = something( 4000 )
	println("Result : $result1")

	val ten = 10
	val result1Again = if ( ten == 10 ) { 	} else {	}
	println( result1Again ) 
	// val something: = { println(4000) }

	val persons = listOf( 
		Person("Gabbar Singh", "Decoit", "Mr."), 
		Person("Bansanti Only", "TangeWali", "Mrs."),
		Person("Radha", "Heroin", "Mrs."),
		Person("Veeru", "Hero", "Mr."),
		Person("Jay", "Hero", "Mr."),
	)

	val names = persons.joinToString( separator = " ", 
		transform = { person: Person -> person.name } )
	println( names )

	// Gabbar Singh Bansanti Only Radha Veeru Jay
	val titles = persons.joinToString( separator = " ", 
		transform = { person: Person -> person.title } )
	println( titles )

	val profiles = persons.joinToString( separator = " ", 
		transform = { person: Person -> person.profile } )
	println( profiles )

	var result: Int
	var multiplyLambda: (Int, Int) -> Int

	multiplyLambda = { a: Int, b: Int -> a * b }	
	result = multiplyLambda( 10, 20 )
	println("Result = $result")

	multiplyLambda = { a, b -> a * b }	
	result = multiplyLambda( 10, 20 )
	println("Result = $result")

	multiplyLambda = { a, b -> 
		a * b 
	}	
	result = multiplyLambda( 10, 20 )
	println("Result = $result")

	var doubleLambda = { a : Int -> 2 * a }
	result = doubleLambda( 11 )
	println("Result = $result")

	doubleLambda = { a : Int -> 
		2 * a 
	}
	result = doubleLambda( 11 )
	println("Result = $result")

	// If Lambda Takes One Argument: Then You Can Refer Using it
	doubleLambda = { 
		2 * it 
	}
	result = doubleLambda( 11 )
	println("Result = $result")

	doubleLambda = { 2 * it }
	result = doubleLambda( 11 )
	println("Result = $result")

	var square: (Int) -> Int  = { number: Int -> number * number }
	result = square( 25 )
	println("Result = $result")

	// square: (Int) -> Int  = { it * it }
	square  = { it * it }
	result = square( 25 )
	println("Result = $result")
}

// __________________________________________________
// COMPLETE HANDS ON! MOMENT DONE RAISE YOUR FLAGS!!!

fun playWithFunctionAndLambdasAgain() {
	var result: Int

	fun operate(a: Int, b: Int, operation: (Int, Int) -> Int ) : Int {
		return operation( a, b)
	}

	val addLambda = { a: Int, b: Int -> a + b }
	result = operate( 40, 20, operation = addLambda )
	println("Result = $result")

	fun addFunction(a: Int, b: Int) = a + b 
	result = operate( 40, 20, operation = ::addFunction )
	println("Result = $result")	

	result = operate( 40, 20, operation = Int::plus )
	println("Result = $result")	

	result = operate( 40, 20, operation = { a: Int, b: Int -> a + b } )
	println("Result = $result")	

	result = operate( 40, 20, operation = { a, b -> a + b } )
	println("Result = $result")	

	result = operate( 40, 20, 
		operation = { a, b -> 
			a + b 
		} )
	println("Result = $result")	

	// Trailing Lambda Syntax
	//		Funcation Taking Last Argument As Lambda
	//			That Lambda Can Be Written Followed By Function Call
	result = operate( 40, 20 ) { a, b -> a + b }
	println("Result = $result")	

	result = operate( 40, 20 ) { 
		a, b -> a + b 
	}
	println("Result = $result")	
}

// __________________________________________________
// COMPLETE HANDS ON! MOMENT DONE RAISE YOUR FLAGS!!!

// Higher Order Function
//		Functions Which Takes Function As Arguments
//				AND/OR
//		Returns Function
//		e.g. Following chooseSteps Is Higher Order Function

fun chooseSteps( backward: Boolean ) : (Int) -> Int {
	//	Following Functions Have Type: 
	//		(Int) -> Int
	fun moveForward( start: Int ) : Int { return start + 1}
	fun moveBackward( start: Int ): Int { return start - 1}

	return if ( backward ) ::moveBackward else ::moveForward
}

fun playWithChooseStepFunction() {
	var result: Int
	// What Is Type Of something?
	val something = chooseSteps( backward = true )
	// (Boolean) -> (Int) -> Int
	// ( (Boolean) -> Int ) -> Int
	result = something( 10 )
	println("Result : $result")

	val somethingAgain: (Int) -> Int = chooseSteps( backward = true )
	result = somethingAgain( 10 )
	println("Result : $result")

	// What Is Type Of somethingMore?
	// (Boolean) -> (Int) -> Int
	val somethingMore = ::chooseSteps

	// What Is Type Of somethingMore?	
	// (Int) -> Int
	val somethingOnceMore = somethingMore( false )

	// What Is Type Of somethingMoreMore?
	// Int	
	val somethingMoreMore = somethingOnceMore( 900 )
	println( somethingMoreMore )

	val somethingMore1: (Boolean) -> (Int) -> Int  = ::chooseSteps
	val somethingOnceMore1: (Int) -> Int = somethingMore1( false )
	val somethingMoreMore1 : Int= somethingOnceMore1( 900 )
	println( somethingMoreMore1 )	
}

// __________________________________________________
class User( val id: Int, val name: String, val address: String )

fun saveUserAgain( user: User ) { // Enclosing Context
	// Local Function
	//		Function Defined Inside A Function
	//		Enclosed Context Captures The Enclosing Context
	fun validate( value: String, fieldName: String ) { // Enclosed Context
		if ( value.isEmpty() ) {
			throw IllegalArgumentException("Can't Save User: For ${ user.id } = $fieldName Empty!")
		}
	}

	fun saveUserInDatabase( user: User ) {
		println("Local Function: Saving User ${user.id} In Database...")	
	} 
	// Validation Of User Data
	validate( user.name, "Name" )
	validate( user.address, "Address" )
	// Save User In Database...
	saveUserInDatabase( user )
}

fun playWithSaveUserAgainFunction() {
	val gabbar 	= User( 420, "Gabbar Singh", "Ramgarh" )
	val samba  	= User( 120, "Samba", "Ramgarh")
	val basanti = User( 100, "Basanti", "Thakur's Village")

	saveUserAgain( gabbar )
	saveUserAgain( samba )
	saveUserAgain( basanti )
}

// __________________________________________________

fun playWithDoSomething() { // Enclosing Context

	val something = 100
	fun doSomething() { // Enclosed Context
		println("Something : $something")
	}
}

// __________________________________________________

// class User( val id: Int, val name: String, val address: String )

fun User.save() { // Enclosing Context
	fun validate( value: String, fieldName: String ) { // Enclosed Context
		if ( value.isEmpty() ) {
			throw IllegalArgumentException("Can't Save User: For ${ this.id } = $fieldName Empty!")
		}
	}

	fun saveUserInDatabase( user: User ) {
		println("Local Function: Saving User ${user.id} In Database...")	
	} 
	// Validation Of User Data
	validate( this.name, "Name" )
	validate( this.address, "Address" )
	// Save User In Database...
	saveUserInDatabase( this )
}

fun playWithSaveExtensionFunction() {
	val gabbar 	= User( 420, "Gabbar Singh", "Ramgarh" )
	val samba  	= User( 120, "Samba", "Ramgarh")
	val basanti = User( 100, "Basanti", "Thakur's Village")

	gabbar.save()
	samba.save()
	basanti.save()
}

// __________________________________________________
// COMPLETE HANDS ON! MOMENT DONE RAISE YOUR FLAGS!!!

// Polymorphism
//		Polymorphic Function
fun filterString( data: String, predicate: (Char) -> Boolean ) : String {
	val sb = StringBuilder()

	for( index in 0 until data.length ) {
		val element = data.get( index )
		if ( predicate( element ) )
			sb.append( element )
	}
	return sb.toString()
}

fun String.filter( predicate: (Char) -> Boolean ) : String {
	val sb = StringBuilder()

	for( index in 0 until this.length ) {
		val element = this.get( index )
		if ( predicate( element ) )
			sb.append( element )
	}
	return sb.toString()
}

fun playWithFilterFunction() {
	val stringData = "ABCDEabem908980atm787BFG"
	var result: String

	result = filterString( stringData, { it in 'a'..'z' } )
	println("Result : $result")

	result = filterString( stringData, { it in 'A'..'Z' } )
	println("Result : $result")

	result = filterString( stringData, { it in '0'..'9' } )
	println("Result : $result")

	result = stringData.filter( { it in 'a'..'z' } )
	println("Result : $result")

	result = stringData.filter { it in 'A'..'Z' } 
	println("Result : $result")

	result = stringData.filter { 
		it in 'A'..'Z' 
	} 
	println("Result : $result")
}

// __________________________________________________
// __________________________________________________
// __________________________________________________
// __________________________________________________
// __________________________________________________
// COMPLETE HANDS ON! MOMENT DONE RAISE YOUR FLAGS!!!

fun main() {
	println("\nFunction: playWithCalculator")
	playWithCalculator()

	println("\nFunction: playWithFunctionAndLambdas")
	playWithFunctionAndLambdas()

	println("\nFunction: playWithFunctionAndLambdasAgain")
	playWithFunctionAndLambdasAgain()

	println("\nFunction: playWithChooseStepFunction")
	playWithChooseStepFunction()

	println("\nFunction: playWithSaveUserAgainFunction")
	playWithSaveUserAgainFunction()

	println("\nFunction: playWithSaveExtensionFunction")
	playWithSaveExtensionFunction()

	println("\nFunction: playWithFilterFunction")
	playWithFilterFunction()

	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
}

/*
	https://codebunk.com/b/6251100617995/
	https://codebunk.com/b/6251100617995/
	https://codebunk.com/b/6251100617995/
*/
