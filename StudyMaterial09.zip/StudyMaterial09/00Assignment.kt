___________________________________________________________________________

DAY 01
___________________________________________________________________________

	Assignment A1 : Reading, Thinking Assignment [ MUST MUST ]
		Chapter 05: Pointers and Arrays 				[ THOROUGH READING ]
		Chapter 02: Types, Operators And Expressions 	[ THOROUGH READING ]

		Reference : The C Programming Language, 2nd Edition
			By Brian Kernigham and Dennis Ritchie

	Assignment A2 : Thinking and Experimentation Assignments [ MUST MUST ]
		Already Given It

	Environment E1: Prepare Environment!
		1. Install Android Studio

___________________________________________________________________________

DAY 02
___________________________________________________________________________

	Assignment A1 : Reading, Thinking Assignment [ MUST MUST ]
		Chapter 05: Pointers and Arrays 				[ THOROUGH READING ]
		Chapter 02: Types, Operators And Expressions 	[ THOROUGH READING ]

		Reference : The C Programming Language, 2nd Edition
			By Brian Kernigham and Dennis Ritchie

	Assignment A2 : Revise, Practice and Experimentation Kotlin Code [ MUST MUST ]
		Revise, Practice and Experiment Kotlin Code In Class Till Now

	Assignment A3 : Thinking and Experimentation Assignments [ MUST MUST ]
		Already Given It

	Environment E1: Prepare Environment!
		1. Install Android Studio


___________________________________________________________________________

DAY 03
___________________________________________________________________________

	Assignment A1 : Revise, Practice and Experimentation Kotlin Code [ MUST MUST ]
		Revise, Practice and Experiment Kotlin Code In Class Till Now

	Assignment A2 : Kotlin Reading Assignments [ MUST MUST ]	
		Reference Book: Kotlin In Action By DMITRY JEMEROV AND SVETLANA ISAKOVA
			Chapter 01: Kotlin: What and Why?
			Chapter 02: Kotlin Basics  				[ THOROUGH READING ]
			Chapter 03: Kotlin Defining and Calling Functions 	[ THOROUGH READING ]

	Assignment A3 : REVISE Reading, Thinking Assignment [ MUST MUST ]
		Chapter 05: Pointers and Arrays 				[ THOROUGH READING ]

		Reference : The C Programming Language, 2nd Edition
			By Brian Kernigham and Dennis Ritchie

	Environment E1: Prepare Environment!
		1. Install Android Studio
		2. Tools > SDK Manager

			Install Android SDK 34 With Following Things
				Android Source Code
				Android Platform SDK
				Google Android System Image x86_64 ( Intel Machine )
				Google Android System Image Arm Architecture ( Mac Machine Machine )

___________________________________________________________________________

DAY 04
___________________________________________________________________________

	Assignment A1 : Revise, Practice and Experimentation Kotlin Code [ MUST MUST ]
		Revise, Practice and Experiment Kotlin Code In Class Till Now

	Assignment A2 : Kotlin Reading Assignments [ MUST MUST ]	
		Reference Book: Kotlin In Action By DMITRY JEMEROV AND SVETLANA ISAKOVA
			Chapter 01: Kotlin: What and Why?
			Chapter 02: Kotlin Basics  							[ THOROUGH READING ]
			Chapter 03: Kotlin Defining and Calling Functions 	[ THOROUGH READING ]
			Chapter 06: Higher Order Functions 					[ THOROUGH READING ]

	Environment E1: Prepare Environment!
		1. Install Android Studio
		2. Tools > SDK Manager

			Install Android SDK 34 With Following Things
				Android Source Code
				Android Platform SDK
				Google Android System Image x86_64 ( Intel Machine )
				Google Android System Image Arm Architecture ( Mac Machine Machine )

___________________________________________________________________________

DAY 05
___________________________________________________________________________

	Assignment A1 : Revise, Practice and Experimentation Kotlin Code [ MUST MUST ]
		Revise, Practice and Experiment Kotlin Code In Class Till Now

	Assignment A2 : Kotlin Reading Assignments [ MUST MUST ]	
		Reference Book: Kotlin In Action By DMITRY JEMEROV AND SVETLANA ISAKOVA
			Chapter 01: Kotlin: What and Why?
			Chapter 02: Kotlin Basics  							[ THOROUGH READING ]
			Chapter 03: Kotlin Defining and Calling Functions 	[ THOROUGH READING ]
			Chapter 04: Classes, Objects and Interfaces   		[ THOROUGH READING ]
			Chapter 05: Programming With Lambda  				[ THOROUGH READING ]
			Chapter 06: Kotlin Type Systems  					[ THOROUGH READING ]
			Chapter 08: Higher Order Functions 					[ THOROUGH READING ]

	Environment E1: Prepare Environment!
		1. Install Android Studio
		2. Tools > SDK Manager

			Install Android SDK 34 With Following Things
				Android Source Code
				Android Platform SDK
				Google Android System Image x86_64 ( Intel Machine )
				Google Android System Image Arm Architecture ( Mac Machine Machine )

___________________________________________________________________________

DAY 06
___________________________________________________________________________

	Assignment A1 : Revise, Practice and Experimentation Kotlin Code [ MUST MUST ]
		Revise, Practice and Experiment Kotlin Code In Class Till Now

	Assignment A2 : Kotlin Reading Assignments [ MUST MUST ]	
		Reference Book: Kotlin In Action By DMITRY JEMEROV AND SVETLANA ISAKOVA
			Chapter 01: Kotlin: What and Why?
			Chapter 02: Kotlin Basics  							[ THOROUGH READING ]
			Chapter 03: Kotlin Defining and Calling Functions 	[ THOROUGH READING ]
			Chapter 04: Classes, Objects and Interfaces   		[ THOROUGH READING ]
			Chapter 05: Programming With Lambda  				[ THOROUGH READING ]
			Chapter 06: Kotlin Type Systems  					[ THOROUGH READING ]
			Chapter 07: Opeartor Overloading 					[ THOROUGH READING ]
			Chapter 08: Higher Order Functions 					[ THOROUGH READING ]

	Assignment A2 : Android Reading Assignments [ MUST MUST ]	
		https://developer.android.com/guide/platform

	Environment E1: Prepare Environment!
		1. Install Android Studio
		2. Tools > SDK Manager

		Install Android SDK 34 With Following Things
			Android Source Code
			Android Platform SDK
			Google Android System Image x86_64 ( Intel Machine )
			Google Android System Image Arm Architecture ( Mac Machine Machine )

		Install Android SDK 30 With Following Things
			Android Source Code
			Android Platform SDK
			Google Android System Image x86_64 ( Intel Machine )
			Google Android System Image Arm Architecture ( Mac Machine Machine )
___________________________________________________________________________

DAY 07
___________________________________________________________________________

Assignment A1: Exploration and Thinking Assignment

	Explore and Understand Following Examples
		1. Download StudyMaterial06.1.zip
		2. Unzip StudyMaterial06.1.zip File
		3. Explore Following Examples

		StudyMaterial06.1.zip
			TestHelloWorld

	Explore and Understand Following Examples
		1. Download StudyMaterial07.1.zip
		2. Unzip StudyMaterial07.1.zip File
		3. Explore Following Examples

		StudyMaterial07.1.zip
			ManifestAndResourcesJava
			ConfigChangesJava
			ActivitiesJava

	Explore and Understand Following Examples
		1. Download StudyMaterial07.2.zip
		2. Unzip StudyMaterial07.2.zip File
		3. Explore Following Examples

		StudyMaterial07.2.zip
			Project.04.01.Layouts

Assignment A2 : Android Reading Assignments [ MUST MUST ]	
	https://developer.android.com/guide/platform
	https://developer.android.com/guide/components/fundamentals
	https://guides.codepath.com/android/Activity-Lifecycle		
	https://developer.android.com/guide/components/activities/intro-activities
	https://developer.android.com/guide/components/activities/activity-lifecycle

___________________________________________________________________________

DAY 08
___________________________________________________________________________

Assignment A1: Exploration and Thinking Assignment

	Explore and Understand Following Examples
		1. Download StudyMaterial08.1.zip
		2. Unzip StudyMaterial08.1.zip File
		3. Explore Following Examples

		StudyMaterial08.1.zip
			Project.04.03.Views
			Project.04.04.Adapters



	Explore and Understand Following Examples
		1. Download StudyMaterial08.2.zip
		2. Unzip StudyMaterial08.2.zip File
		3. Explore Following Examples

		StudyMaterial08.2
			Project.05.01.Intents
			Project.05.03.BroadcastIntents





Assignment A2 : Android Reading Assignments [ MUST MUST ]	
	https://developer.android.com/guide/platform
	https://developer.android.com/guide/components/fundamentals
	https://guides.codepath.com/android/Activity-Lifecycle		
	https://developer.android.com/guide/components/activities/intro-activities
	https://developer.android.com/guide/components/activities/activity-lifecycle

	https://developer.android.com/guide/components/activities/state-changes
	https://developer.android.com/reference/android/content/Intent
	https://developer.android.com/guide/components/intents-filters
	https://developer.android.com/guide/components/activities/tasks-and-back-stack

	https://guides.codepath.com/android/Using-an-ArrayAdapter-with-ListView
	https://guides.codepath.com/android/Using-the-RecyclerView

___________________________________________________________________________

DAY 09
___________________________________________________________________________

Assignment A1: Exploration and Thinking Assignment

	Explore and Understand Following Examples
		1. Download StudyMaterial09.1.zip
		2. Unzip StudyMaterial09.1.zip File
		3. Explore Following Examples

		StudyMaterial09.1.zip		
			AndroidFragmentFundamentals  
			AndroidFragmentPizza
	

Assignment A2: Exploration and Thinking Assignment

	Explore and Understand Following Examples
		1. Download StudyMaterial09.1.zip
		2. Unzip StudyMaterial09.1.zip File
		3. Explore Following Examples

		StudyMaterial09.1.zip
			AndroidFundamentals

Assignment A3 : Android Reading Assignments [ MUST MUST ]	
	https://developer.android.com/guide/platform
	https://developer.android.com/guide/components/fundamentals
	https://guides.codepath.com/android/Activity-Lifecycle		
	https://developer.android.com/guide/components/activities/intro-activities
	https://developer.android.com/guide/components/activities/activity-lifecycle

	https://developer.android.com/guide/components/activities/state-changes
	https://developer.android.com/reference/android/content/Intent
	https://developer.android.com/guide/components/intents-filters
	https://developer.android.com/guide/components/activities/tasks-and-back-stack

	https://guides.codepath.com/android/Using-an-ArrayAdapter-with-ListView
	https://guides.codepath.com/android/Using-the-RecyclerView

	https://medium.com/androiddevelopers/the-android-lifecycle-cheat-sheet-part-iii-fragments-afc87d4f37fd
	https://developer.android.com/guide/fragments#:~:text=A%20Fragment%20represents%20a%20reusable,an%20activity%20or%20another%20fragment.
	https://developer.android.com/guide/fragments/fragmentmanager
	https://developer.android.com/guide/fragments/transactions
	https://developer.android.com/guide/fragments/lifecycle
	https://developer.android.com/guide/fragments/saving-state
	https://developer.android.com/guide/fragments/communicate

	https://developer.android.com/guide/components/services

__________________________________________________

>>>>>>>>>>>>>> FEEDBACK LINK <<<<<<<<<<<< 
__________________________________________________

https://feedbackind.vinsys.com/Indiafeedback.html?batch_id%3D2089
https://feedbackind.vinsys.com/Indiafeedback.html?batch_id%3D2089
https://feedbackind.vinsys.com/Indiafeedback.html?batch_id%3D2089

__________________________________________________


___________________________________________________________________________
___________________________________________________________________________
___________________________________________________________________________
___________________________________________________________________________

