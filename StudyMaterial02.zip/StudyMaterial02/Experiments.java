
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class Experiments {
    public static void playWithArrayLists() {
        ArrayList<String> friends = new ArrayList<>();
        friends.add("Peter");
        friends.add("Paul");
        friends.add("Gabbar");
        ArrayList<String> people = friends;

        System.out.println("friends=" + friends);
        System.out.println("people =" + people);

        people.set(0, "Mary");
        
        System.out.println("friends=" + friends);
        System.out.println("people =" + people);

        for (int i = 0; i < friends.size(); i++) {
            System.out.println( friends.get(i) );
        }

        for (int i = 0; i < people.size(); i++) {
            System.out.println( people.get(i) );
        }
    }

    public static void main(String[] args) {
    	playWithArrayLists();
    }	
}

