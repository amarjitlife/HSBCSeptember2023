/*
// Ccmpiling Hello.kt File
	kotlinc Hello.kt -include-runtime -d hello.jar

// Running  hello.jar File
	java -jar hello.jar
*/

// __________________________________________________
// DO FOLLOWING CODE! MOMENT DONE RAISE YOUR HANDS!!!

//	Function Doesn't Takes Any Argument
fun helloWorld() {
	println("Hello World!")
}

// __________________________________________________
// DO FOLLOWING CODE! MOMENT DONE RAISE YOUR HANDS!!!

//	Function 
//		Takes Two Arguments Of Int Type
//		Return Value Of Int Type
// if-else Construct
// In C/C++/Java
//		if-else Construct Is A Statement
//	In Kotlin
//		if-else Construct Is An Expression
//		Expression Is A Statement With Return Value

fun max(a: Int, b: Int) : Int {
	return if ( a > b ) a else b  
/*
	return if ( a > b ) { 
		a
		a + 1000 
	} else {
		b
		b - 200
	}
*/ 
}

fun playWithMaxFunction() {
	println( max( 100, 200 ) )
	println( max( 300, -300 ) )
}

// __________________________________________________
// COMPLETE HANDS ON! MOMENT DONE RAISE YOUR FLAGS!!!

// Person Class Have 2 Properties
//		viz. name of String Type
//			 isMarried of Boolean Type
//		val Properties are Immutable
//		var Properties are Mutable

// Compiler Will Generate Following Members For Person Class
//		1. Will Generate Memberwise Initialiser
//				i.e. Constructor Taking Two Arguments 
//		2. Will Generate Two Member Variable For Two Properties
//		3. Will Geneate Getter and Setter For Mutable Property
//		4. Will Geneate Getter and For IMMutable Property

class Person( val name: String, var isMarried: Boolean ) 

fun playWithPErson() {
						// Calling Memberwise Constructor	
	val gabbar = Person( "Gabbar Singh", false  )
	println( gabbar.name ) 			// gabbar.getName()
	println( gabbar.isMarried ) 	// gabbar.getIsMarried()

	// error: val cannot be reassigned
	// gabbar.name = "Gabbar Singh Decoit"
	gabbar.isMarried = true  		// gabbar.setIsMarried( true )

	println( gabbar.name )
	println( gabbar.isMarried )

	val basanti = Person("Basanti", false )
	println( basanti.name )
	println( basanti.isMarried )
}

// __________________________________________________
// COMPLETE HANDS ON! MOMENT DONE RAISE YOUR FLAGS!!!

// Creating Rectangle Class with Three Properties
//		1. viz. height, width and isSquare
//		2. All Properties Are Immutable
//		3. For height, width Getters Will Be Generated
//		4. Properties with Custom Getters/Setters 
//			Compiler Will Not Generate Getters/Setters

class Rectangle( val height: Int, val width: Int ) {
	val isSquare : Boolean
		get() { // Custom Getter
			return height == width
		}
}

fun playWithRectangle() {
	val rectangle1 = Rectangle( 200, 400 )
	println( rectangle1.width )
	println( rectangle1.height )
	println( rectangle1.isSquare )

	val rectangle2 = Rectangle( 400, 400 )
	println( rectangle2.width )
	println( rectangle2.height )
	println( rectangle2.isSquare )
}

// __________________________________________________

fun playWithTypesInferrencingAndBinding() {
	// What Is The Type Of something
	// In Python
	//		Type Inferrencing and Binding Will Happen At Run Time
	// In Kotlin
	//		Type Inferrencing and Binding Will Happen At Compile Time
	// Implicitly Type Inferencing Will Happen
	// 1. Type Inferred From RHS
	// 2. Inferred Type Binded With LHS
	val something = 10
	println( something )

	// Explicitly Annotating The Type
	val somethingAgain: Int = 10
	println( somethingAgain )

	val someValue = 90.90
	println( someValue )
} 


// __________________________________________________
// __________________________________________________
// __________________________________________________
// __________________________________________________
// __________________________________________________

fun main() {
	println("\nFuntion: helloWorld")
	helloWorld()

	println("\nFunction: playWithMaxFunction")
	playWithMaxFunction()

	println("\nFunction: playWithPErson")
	playWithPErson()

	println("\nFunction: playWithRectangle")
	playWithRectangle()

	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
}

