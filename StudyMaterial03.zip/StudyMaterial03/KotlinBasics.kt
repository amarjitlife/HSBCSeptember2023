/*
Ccmpiling Kotlin File
kotlinc KotlinBasics.kt -include-runtime -d basics.jar

Running Jar File
java -jar basics.jar
*/

import java.util.TreeMap

// __________________________________________________
// DO FOLLOWING CODE! MOMENT DONE RAISE YOUR HANDS!!!

//	Function Doesn't Takes Any Argument
fun helloWorld() {
	println("Hello World!")
}

// __________________________________________________
// DO FOLLOWING CODE! MOMENT DONE RAISE YOUR HANDS!!!

//	Function 
//		Takes Two Arguments Of Int Type
//		Return Value Of Int Type
// if-else Construct
// 		In C/C++/Java : 
//			if-else Construct Is A Statement
//		In Kotlin
//			if-else Construct Is An Expression
//			Expression Is A Statement With Return Value

// In Java
// int max(int a, int b ) {
// 	if ( a > b ) { 
// 		return a;
// 	} else {
// 		return b;
// 	}
// }

fun max(a: Int, b: Int) : Int {
	return if ( a > b ) a else b  

	// return if ( a > b ) { 
	// 	a
	// 	a + 1000 
	// } else {
	// 	b
	// 	b - 200
	// } 
}

fun maximum(a: Int, b: Int) : Int = if ( a > b ) a else b //"Hello" 
// error: type mismatch: inferred type is String but Int was expected
// fun maximum1(a: Int, b: Int) : Int = if ( a > b ) a else "Hello" 

fun maximumAgain(a: Int, b: Int)  = if ( a > b ) a else b  

// Following Both Function Definitions Are Equivalent
// 		Inferred Type From RHS Is Any
//			i.e. Type Of if-else Expression Is Any
fun maximumAgain1(a: Int, b: Int)  = if ( a > b ) a else "Hello"

fun maximumAgain2(a: Int, b: Int) : Any = if ( a > b ) a else "Hello"

fun playWithMaxFunction() {
	println( max( 100, 200 ) )
	println( max( 300, -300 ) )

	println( maximum( 100, 200 ) )
	println( maximum( 300, -300 ) )

	println( maximumAgain( 100, 200 ) )
	println( maximumAgain( 300, -300 ) )

	println( maximumAgain1( 100, 200 ) )
	println( maximumAgain1( 300, -300 ) )
}

// __________________________________________________
// COMPLETE HANDS ON! MOMENT DONE RAISE YOUR FLAGS!!!

// Person Class Have 2 Properties
//		viz. name of String Type
//			 isMarried of Boolean Type
//		val Properties are Immutable
//		var Properties are Mutable

// Compiler Will Generate Following Members For Person Class
//		1. Will Generate Memberwise Initialiser
//				i.e. Constructor Taking Two Arguments 
//		2. Will Generate Two Member Variable For Two Properties
//		3. Will Geneate Getter and Setter For Mutable Property
//		4. Will Geneate Getter and For IMMutable Property
class Person( val name: String, var isMarried: Boolean ) 

fun playWithPErson() {
						// Calling Memberwise Constructor	
	val gabbar = Person( "Gabbar Singh", false  )
	println( gabbar.name ) 			// gabbar.getName()
	println( gabbar.isMarried ) 	// gabbar.getIsMarried()

	// error: val cannot be reassigned
	// gabbar.name = "Gabbar Singh Decoit"
	gabbar.isMarried = true  		// gabbar.setIsMarried( true )

	println( gabbar.name )
	println( gabbar.isMarried )

	val basanti = Person("Basanti", false )
	println( basanti.name )
	println( basanti.isMarried )
}

// __________________________________________________
// COMPLETE HANDS ON! MOMENT DONE RAISE YOUR FLAGS!!!

// Creating Rectangle Class with Three Properties
//		1. viz. height, width and isSquare
//		2. All Properties Are Immutable
//		3. For height, width Getters Will Be Generated
//		4. Properties with Custom Getters/Setters 
//			Compiler Will Not Generate Getters/Setters

class Rectangle( val height: Int, val width: Int ) {
	val isSquare : Boolean
		get() { // Custom Getter Defined By Programmer
			//		Hence Compiler Will Not Generate 
			return height == width
		}
}

fun playWithRectangle() {
	val rectangle1 = Rectangle( 200, 400 )
	println( rectangle1.width ) 		//rectangle1.getWidth(()
	println( rectangle1.height ) 		//rectangle1.getHeight()
	println( rectangle1.isSquare ) 		//rectangle2.getIsSquare(()

	val rectangle2 = Rectangle( 400, 400 )
	println( rectangle2.width )
	println( rectangle2.height )
	println( rectangle2.isSquare )
}

// __________________________________________________
// COMPLETE HANDS ON! MOMENT DONE RAISE YOUR FLAGS!!!

fun playWithTypesInferrencingAndBinding() {
	// What Is The Type Of something
	// In Python
	//		Type Inferrencing and Binding Will Happen At Run Time
	// In Kotlin
	//		Type Inferrencing and Binding Will Happen At Compile Time
	// Implicitly Type Inferencing Will Happen
	// 1. Type Inferred From RHS
	// 2. Inferred Type Binded With LHS
	val something = 10
	println( something )
	// Explicitly Annotating The Type
	val somethingAgain: Int = 10

	// error: type mismatch: inferred type is String but Int was expected
	// val somethingAgainI: Int = "Hello World"
	println( somethingAgain )

	// error: the floating-point literal does not conform to the 
	// expected type Float
	// val someValue: Float = 90.90
	val someValue = 90.90 // Default Type Is Kotlin Double
	println( someValue )

	val someValue1 = 90.90F // RHS Value Is Float Type
	println( someValue1 )

	val someValueAgain = 90.90 // Default Type Is Kotlin Double
	println( someValueAgain )

	val someValueAgain1: Double = 90.90 // Default Type Is Kotlin Double
	println( someValueAgain1 )

	val greeting = "Good Evening!"
	val greetingAgain: String = "Good Evening"

	println( greeting )
	println( greetingAgain )
} 

// __________________________________________________
// COMPLETE HANDS ON! MOMENT DONE RAISE YOUR FLAGS!!!

// Colour Type
//		Range Of Colour = { RED, GREEN, BLUE, YELLOW } 

enum class Colour {
	RED, GREEN, BLUE, YELLOW
}

// DESIGN PRINCIPLE
//		Prefer Listing All Branches Rather Than else Branch
//		else Branch Should Be Used In Rarest Rare Case

fun getColourString( colour: Colour ) : String {
	// when Is Similar To switch
	// In C/C++/Java 
	//		switch Is A Statement
	// In Kotlin 
	//		when Is An Type Safe Expression
	//			Hence It Has Return Value
	//		break Is Implicit In when Branches 
	return when( colour ) {
		// Mapping A Enum Value of Colour Type To String Value
		Colour.RED 		-> "Red Colour"
		Colour.GREEN 	-> "Green Colour"
		Colour.BLUE 	-> "Blue Color"
		// error: 'when' expression must be exhaustive, 
		// add necessary 'YELLOW' branch or 'else' branch instead
		Colour.YELLOW 	-> "Yellow Colour"
		// else 			-> "Unknown Colour" 
	}
}

fun getColourStringAgain( colour: Colour ) : String {
	// when Is Similar To switch
	// In C/C++/Java 
	//		switch Is A Statement
	// In Kotlin 
	//		when Is An Expression
	//			Hence It Has Return Value
	//		break Is Implicit In when Branches 
	return when( colour ) {
		// Mapping A Enum Value of Colour Type To String Value
		Colour.RED 		-> "Red Colour"
		Colour.GREEN 	-> "Green Colour"
		Colour.BLUE 	-> "Blue Color"
		// error: 'when' expression must be exhaustive, 
		// add necessary 'YELLOW' branch or 'else' branch instead
		Colour.YELLOW 	-> "Yellow Colour"
		// else 		-> "Unknown Colour" 
	}
}

fun playWithColours() {
	println( Colour.RED )
	println( Colour.GREEN )
	println( Colour.BLUE )

	println( getColourString( Colour.RED ) )
	println( getColourString( Colour.GREEN ) )
	println( getColourString( Colour.BLUE ) )
	println( getColourString( Colour.YELLOW ) )

	println( getColourStringAgain( Colour.YELLOW ) )
}

// __________________________________________________
// COMPLETE HANDS ON! MOMENT DONE RAISE YOUR FLAGS!!!

// Interface 
interface Expr
// Class Num Implementing Interface Expr
class Num( val value: Int ) : Expr
// Class Sum Implementing Interface Expr
class Sum( val left: Expr, val right: Expr ) : Expr
// fun evalTemp1( e: Num ) : Int {
// 	return e.value
// }

// fun evalTemp2( e: Sum ) : Int {	
// 	return evalTemp2( e.left ) + evalTemp2( e.right )
// }

fun eval( e: Expr ) : Int {
	// Here What Is The Type Of e
	//		e Type Is Expr 
	if ( e is Num ) { // Smart Type Casting
		return e.value
	}

	if ( e is Sum ) {
		return eval( e.left ) + eval( e.right )
	}

	throw IllegalArgumentException("Unknown Expression!!!")
}

fun playWithEval() {
	var result : Int
	result = eval( Sum( Num( 100 ), Num( 200 )) )
	println( "Result: $result" )

	result = eval( Sum( Sum( Num( 100 ), Num( 200 )), Num( 1000 ) ) )
	println( "Result: $result" )
}

// __________________________________________________
// COMPLETE HANDS ON! MOMENT DONE RAISE YOUR FLAGS!!!

// interface Expr
// class Num( val value: Int ) : Expr
// class Sum( val left: Expr, val right: Expr ) : Expr

fun evalIf( e: Expr ) : Int {
	return if ( e is Num ) { // Smart Type Casting
		e.value
	} else if ( e is Sum ) {
		evalIf( e.left ) + evalIf( e.right )
	} else {
		throw IllegalArgumentException("Unknown Expression!!!")
	}
}

fun playWithEvalIf() {
	var result : Int
	result = evalIf( Sum( Num( 100 ), Num( 200 )) )
	println( "Result: $result" )

	result = evalIf( Sum( Sum( Num( 100 ), Num( 200 )), Num( 1000 ) ) )
	println( "Result: $result" )
}

// __________________________________________________
// COMPLETE HANDS ON! MOMENT DONE RAISE YOUR FLAGS!!!

// interface Expr
// class Num( val value: Int ) : Expr
// class Sum( val left: Expr, val right: Expr ) : Expr

fun evalIfAgain( e: Expr ) : Int = if ( e is Num ) { 
		e.value
	} else if ( e is Sum ) {
		evalIfAgain( e.left ) + evalIfAgain( e.right )
	} else {
		throw IllegalArgumentException("Unknown Expression!!!")
}

fun playWithEvalIfAgain() {
	var result : Int
	result = evalIfAgain( Sum( Num( 100 ), Num( 200 )) )
	println( "Result: $result" )

	result = evalIfAgain( Sum( Sum( Num( 100 ), Num( 200 )), Num( 1000 ) ) )
	println( "Result: $result" )
}

// __________________________________________________
// COMPLETE HANDS ON! MOMENT DONE RAISE YOUR FLAGS!!!

// interface Expr
// class Num( val value: Int ) : Expr
// class Sum( val left: Expr, val right: Expr ) : Expr

fun evalulate( expression: Expr ) : Int = when ( expression ) { 
// error: type checking has run into a recursive problem. 
//		Easiest workaround: specify types of your declarations explicitly
// fun evalulate( expression: Expr ) = when ( expression ) { 
	is Num  -> 	expression.value
	is Sum 	-> 	evalulate( expression.left ) + evalulate( expression.right )
	else  	->  throw IllegalArgumentException("Unknown Expression!!!")
}

fun playWithEvaluate() {
	var result : Int
	result = evalulate( Sum( Num( 100 ), Num( 200 )) )
	println( "Result: $result" )

	result = evalulate( Sum( Sum( Num( 100 ), Num( 200 )), Num( 1000 ) ) )
	println( "Result: $result" )
}

// __________________________________________________
// COMPLETE HANDS ON! MOMENT DONE RAISE YOUR FLAGS!!!

// Pattern Matching
fun fizzBuzz( number : Int ) = when {
	number % 15 == 0 -> "FizzBuzz "
	number %  5 == 0 -> "Fizz "
	number %  3 == 0 -> "Buzz "
	else 			 -> " $number " 
}

fun playWithFizzBuzz() {
	for ( i in 1..100 ) { // Close Interval [1, 100]
		print( fizzBuzz( i ) )
	}

	for( i in 100 downTo 1 step 2 ) {
		print( fizzBuzz( i ) )
	}
}

// __________________________________________________
// COMPLETE HANDS ON! MOMENT DONE RAISE YOUR FLAGS!!!

// import java.util.TreeMap

// Can Use Java Collections Classes Inside Kotlin Code
@OptIn(ExperimentalStdlibApi::class)
fun iteratingOverMaps() {
	//							Using Java Collection Classes In Kotlin Code
	val binaryRepresentation = TreeMap<Char, String>()

	for( character in 'A'..'M' ) {
		val binary = Integer.toBinaryString( character.code )
		binaryRepresentation[ character ] = binary
	}

	for ( (letter, binary) in binaryRepresentation ) {
		println("\t $letter = $binary")
	}
}

// __________________________________________________
// COMPLETE HANDS ON! MOMENT DONE RAISE YOUR FLAGS!!!

fun isLetter( character : Char ) 	= character in 'a'..'z' || character in 'A'..'Z'
fun isNotDigit( character: Char ) 	= character !in '0'..'9'

fun recognise( character : Char ) = when( character ) {
	in '0'..'9' 				-> "It's Digit"
	in 'a'..'z', in 'A'..'Z'	-> "It's Letter"
	else 						-> "Unknown Character..."
}

fun usingInCheck() {
	println( isLetter('A' ) )
	println( isLetter('0' ) )

	println( isNotDigit('A' ) )
	println( isNotDigit('0' ) )

	println( recognise('A' ) )
	println( recognise('m' ) )
	println( recognise('0' ) )
}

// __________________________________________________
// __________________________________________________
// __________________________________________________
// COMPLETE HANDS ON! MOMENT DONE RAISE YOUR FLAGS!!!

fun main() {
	println("\nFuntion: helloWorld")
	helloWorld()

	println("\nFunction: playWithMaxFunction")
	playWithMaxFunction()

	println("\nFunction: playWithPErson")
	playWithPErson()

	println("\nFunction: playWithRectangle")
	playWithRectangle()

	println("\nFunction: playWithColours")
	playWithColours()

	println("\nFunction: playWithEval")
	playWithEval()

	println("\nFunction: playWithEvalIf")
	playWithEvalIf()

	println("\nFunction: playWithEvalIfAgain")
	playWithEvalIfAgain()

	println("\nFunction: playWithEvaluate")
	playWithEvaluate()

	println("\nFunction: playWithFizzBuzz")
	playWithFizzBuzz()

	println("\n\nFunction: iteratingOverMaps")
	iteratingOverMaps()

	println("\nFunction: usingInCheck")
	usingInCheck()

	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
}

