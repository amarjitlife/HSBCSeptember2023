/*
Ccmpiling Kotlin File
kotlinc KotlinFunctionsMore.kt -include-runtime -d functionsMore.jar

Running Jar File
java -jar functionsMore.jar
*/

// __________________________________________________
// DO FOLLOWING CODE! MOMENT DONE RAISE YOUR HANDS!!!

// Function Type
//		(Int, Int) -> Int i.e. Function Taking Two Int and Returning Int 
fun sum( x: Int, y: Int ) : Int = x + y
fun sub( x: Int, y: Int ) : Int = x - y
fun mul( x: Int, y: Int ) : Int = x * y

fun sum3( x: Int, y: Int, z: Int ) : Int = x + y + z

// Polymorphic Function
//		Mechanism: By Passing Behaviour To Behviour
fun calculator( x: Int, y: Int, operation: (Int, Int) -> Int ) : Int {
	return operation( x, y )
}

	// val someValue = ::calculator

fun playWithCalculator() {
	val a = 300
	val b = 100
	var result: Int

	result = calculator(a, b, ::sum )
	println("Result : $result")

	result = calculator(a, b, ::sub )
	println("Result : $result")

	result = calculator(a, b, ::mul )
	println("Result : $result")
					// Lambda Expression
	val sumLambda = { x: Int, y: Int -> x + y }
	result = calculator(a, b, sumLambda )
	println("Result : $result")

	val sumLambdaAgain: (Int, Int) -> Int = { x: Int, y: Int -> x + y }
	result = calculator(a, b, sumLambdaAgain )
	println("Result : $result")

	result = calculator(a, b,  { x: Int, y: Int -> x + y } )
	println("Result : $result")

	val subLambda = { x: Int, y: Int -> x - y }
	result = calculator(a, b, subLambda )
	println("Result : $result")

	// error: type mismatch: inferred type is KFunction2<Int, Int, Int> but Int was expected
	// val something: Int = ::sum
	var something = ::sum // ::sum Is Reference To Function sum
	result = something(10, 20)
	println("Result : $result")

	// error: type mismatch: inferred type is KFunction3<Int, Int, Int, Int> 
	// but KFunction2<Int, Int, Int> was expected
	// something = ::sum3

	val somethingAgain: (Int, Int) -> Int= ::sum
	result = somethingAgain(10, 20)
	println("Result : $result")

	val someValue: (Int, Int, (Int, Int) -> Int ) -> Int  = ::calculator
	result = someValue( 111, 222, ::sum )
	println("Result : $result")
}

// __________________________________________________
// __________________________________________________
// __________________________________________________
// __________________________________________________
// __________________________________________________
// __________________________________________________
// COMPLETE HANDS ON! MOMENT DONE RAISE YOUR FLAGS!!!

fun main() {
	println("\nFunction: playWithCalculator")
	playWithCalculator()

	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
}

/*
	https://codebunk.com/b/6251100617995/
	https://codebunk.com/b/6251100617995/
	https://codebunk.com/b/6251100617995/
*/
