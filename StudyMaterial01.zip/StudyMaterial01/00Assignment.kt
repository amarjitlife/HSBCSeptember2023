___________________________________________________________________________

DAY 01
___________________________________________________________________________

	Assignment A1 : Reading, Thinking Assignment [ MUST MUST ]
		Chapter 05: Pointers and Arrays 				[ THOROUGH READING ]
		Chapter 02: Types, Operators And Expressions 	[ THOROUGH READING ]

		Reference : The C Programming Language, 2nd Edition
			By Brian Kernigham and Dennis Ritchie

	Assignment A2 : Thinking and Experimentation Assignments [ MUST MUST ]
		Already Given It


	Environment E1: Prepare Environment!
		1. Install Android Studio

___________________________________________________________________________
___________________________________________________________________________
___________________________________________________________________________
___________________________________________________________________________
___________________________________________________________________________

