#include<stdio.h>
#include<limits.h>
#include <stdlib.h>

// __________________________________________________

int sum( int x, int y ) {
	return x + y;
}

void playWithSum() {
	int result = 0, a = 0, b = 0;

	a = 2147483647;
	b = 10;
	result = sum(a, b);
	printf("\nResult : %d", result );

	a = -2147483648;
	b = -40;
	result = sum(a, b);
	printf("\nResult : %d", result );
}

// Function : playWithSum
// Result : -2147483639
// Result :  214748360

// __________________________________________________
// COMPLETE HANDS ON! MOMENT DONE RAISE YOUR FLAGS!!!

int summation( int a, int b ) {
	int result = 0;
	
	if( ( b > 0 && a > ( INT_MAX - b ) ) || 
		( b < 0 && a < ( INT_MIN - b ) ) ) {
		printf("\nCan't Calculate Sum For Given x,y Values");
		printf("\nRESULT IS INVALID");
		// exit( 1 );
	} else {
		result = a + b;
		return result;
	}
}

void playWithSummation() {
	int result = 0, a = 0, b = 0;

	a = 2147483647;
	b = 10;
	result = summation(a, b);
	printf("\nResult : %d", result );

	a = -2147483648;
	b = -40;
	result = summation(a, b);
	printf("\nResult : %d", result );
}

// __________________________________________________
// __________________________________________________
// __________________________________________________
// __________________________________________________
// __________________________________________________
// __________________________________________________

int main() {
	printf("\n\nFunction : playWithSum");
	playWithSum();

	printf("\n\nFunction : playWithSummation");
	playWithSummation();

	// printf("\n\nFunction : ");
	// printf("\n\nFunction : ");
	// printf("\n\nFunction : ");
	// printf("\n\nFunction : ");
	// printf("\n\nFunction : ");
	// printf("\n\nFunction : ");
	// printf("\n\nFunction : ");
}
