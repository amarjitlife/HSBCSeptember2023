/*
// Ccmpiling Hello.kt File
	kotlinc Hello.kt -include-runtime -d hello.jar

// Running  hello.jar File
	java -jar hello.jar
*/

// __________________________________________________
// DO FOLLOWING CODE! MOMENT DONE RAISE YOUR HANDS!!!

//	Function Doesn't Takes Any Argument
fun helloWorld() {
	println("Hello World!")
}

// __________________________________________________
// DO FOLLOWING CODE! MOMENT DONE RAISE YOUR HANDS!!!

//	Function 
//		Takes Two Arguments Of Int Type
//		Return Value Of Int Type
// if-else Construct
// In C/C++/Java
//		if-else Construct Is A Statement
//	In Kotlin
//		if-else Construct Is An Expression
//		Expression Is A Statement With Return Value

fun max(a: Int, b: Int) : Int {
	return if ( a > b ) a else b  
/*
	return if ( a > b ) { 
		a
		a + 1000 
	} else {
		b
		b - 200
	}
*/ 
}

fun playWithMaxFunction() {
	println( max( 100, 200 ) )
	println( max( 300, -300 ) )
}

// __________________________________________________
// COMPLETE HANDS ON! MOMENT DONE RAISE YOUR FLAGS!!!

// Person Class Have 2 Properties
//		viz. name of String Type
//			 isMarried of Boolean Type
//		val Properties are Immutable
//		var Properties are Mutable

// Compiler Will Generate Following Members For Person Class
//		1. Will Generate Memberwise Initialiser
//				i.e. Constructor Taking Two Arguments 
//		2. Will Generate Two Member Variable For Two Properties
//		3. Will Geneate Getter and Setter For Mutable Property
//		4. Will Geneate Getter and For IMMutable Property

class Person( val name: String, var isMarried: Boolean ) 

fun playWithPErson() {
						// Calling Memberwise Constructor	
	val gabbar = Person( "Gabbar Singh", false  )
	println( gabbar.name ) 			// gabbar.getName()
	println( gabbar.isMarried ) 	// gabbar.getIsMarried()

	// error: val cannot be reassigned
	// gabbar.name = "Gabbar Singh Decoit"
	gabbar.isMarried = true  		// gabbar.setIsMarried( true )

	println( gabbar.name )
	println( gabbar.isMarried )

	val basanti = Person("Basanti", false )
	println( basanti.name )
	println( basanti.isMarried )
}

// __________________________________________________
// COMPLETE HANDS ON! MOMENT DONE RAISE YOUR FLAGS!!!

// Creating Rectangle Class with Three Properties
//		1. viz. height, width and isSquare
//		2. All Properties Are Immutable
//		3. For height, width Getters Will Be Generated
//		4. Properties with Custom Getters/Setters 
//			Compiler Will Not Generate Getters/Setters

class Rectangle( val height: Int, val width: Int ) {
	val isSquare : Boolean
		get() { // Custom Getter
			return height == width
		}
}

fun playWithRectangle() {
	val rectangle1 = Rectangle( 200, 400 )
	println( rectangle1.width )
	println( rectangle1.height )
	println( rectangle1.isSquare )

	val rectangle2 = Rectangle( 400, 400 )
	println( rectangle2.width )
	println( rectangle2.height )
	println( rectangle2.isSquare )
}

// __________________________________________________
// COMPLETE HANDS ON! MOMENT DONE RAISE YOUR FLAGS!!!

fun playWithTypesInferrencingAndBinding() {
	// What Is The Type Of something
	// In Python
	//		Type Inferrencing and Binding Will Happen At Run Time
	// In Kotlin
	//		Type Inferrencing and Binding Will Happen At Compile Time
	// Implicitly Type Inferencing Will Happen
	// 1. Type Inferred From RHS
	// 2. Inferred Type Binded With LHS
	val something = 10
	println( something )
	// Explicitly Annotating The Type
	val somethingAgain: Int = 10

	// error: type mismatch: inferred type is String but Int was expected
	// val somethingAgainI: Int = "Hello World"
	println( somethingAgain )

	// error: the floating-point literal does not conform to the 
	// expected type Float
	// val someValue: Float = 90.90
	val someValue = 90.90 // Default Type Is Kotlin Double
	println( someValue )

	val someValue1 = 90.90F // RHS Value Is Float Type
	println( someValue1 )

	val someValueAgain = 90.90 // Default Type Is Kotlin Double
	println( someValueAgain )

	val someValueAgain1: Double = 90.90 // Default Type Is Kotlin Double
	println( someValueAgain1 )

	val greeting = "Good Evening!"
	val greetingAgain: String = "Good Evening"

	println( greeting )
	println( greetingAgain )
} 

// __________________________________________________
// COMPLETE HANDS ON! MOMENT DONE RAISE YOUR FLAGS!!!

// Colour Type
//		Range Of Colour = { RED, GREEN, BLUE, YELLOW } 

enum class Colour {
	RED, GREEN, BLUE, YELLOW
}

// DESIGN PRINCIPLE
//		Prefer Listing All Branches Rather Than else Branch
//		else Branch Should Be Used In Rarest Rare Case

fun getColourString( colour: Colour ) : String {
	// when Is Similar To switch
	// In C/C++/Java 
	//		switch Is A Statement
	// In Kotlin 
	//		when Is An Type Safe Expression
	//			Hence It Has Return Value
	//		break Is Implicit In when Branches 
	return when( colour ) {
		// Mapping A Enum Value of Colour Type To String Value
		Colour.RED 		-> "Red Colour"
		Colour.GREEN 	-> "Green Colour"
		Colour.BLUE 	-> "Blue Color"
		// error: 'when' expression must be exhaustive, 
		// add necessary 'YELLOW' branch or 'else' branch instead
		Colour.YELLOW 	-> "Yellow Colour"
		// else 			-> "Unknown Colour" 
	}
}

fun getColourStringAgain( colour: Colour ) : String {
	// when Is Similar To switch
	// In C/C++/Java 
	//		switch Is A Statement
	// In Kotlin 
	//		when Is An Expression
	//			Hence It Has Return Value
	//		break Is Implicit In when Branches 
	return when( colour ) {
		// Mapping A Enum Value of Colour Type To String Value
		Colour.RED 		-> "Red Colour"
		Colour.GREEN 	-> "Green Colour"
		Colour.BLUE 	-> "Blue Color"
		// error: 'when' expression must be exhaustive, 
		// add necessary 'YELLOW' branch or 'else' branch instead
		Colour.YELLOW 	-> "Yellow Colour"
		// else 		-> "Unknown Colour" 
	}
}

fun playWithColours() {
	println( Colour.RED )
	println( Colour.GREEN )
	println( Colour.BLUE )

	println( getColourString( Colour.RED ) )
	println( getColourString( Colour.GREEN ) )
	println( getColourString( Colour.BLUE ) )
	println( getColourString( Colour.YELLOW ) )

	println( getColourStringAgain( Colour.YELLOW ) )
}

// __________________________________________________
// COMPLETE HANDS ON! MOMENT DONE RAISE YOUR FLAGS!!!

interface Expr
class Num( val value: Int ) : Expr
class Sum( val left: Expr, val right: Expr ) : Expr

fun eval( e: Expr ) : Int {
	if ( e is Num ) {
		return e.value
	}

	if ( e is Sum ) {
		return eval( e.left ) + eval( e.right )
	}

	throw IllegalArgumentException("Unknown Expression!!!")
}

fun playWithEval() {
	var result : Int
	result = eval( Sum( Num( 100 ), Num( 200 )) )
	println( "Result: $result" )

	result = eval( Sum( Sum( Num( 100 ), Num( 200 )), Num( 1000 ) ) )
	println( "Result: $result" )
}

// __________________________________________________
// __________________________________________________
// __________________________________________________
// __________________________________________________
// __________________________________________________

fun main() {
	println("\nFuntion: helloWorld")
	helloWorld()

	println("\nFunction: playWithMaxFunction")
	playWithMaxFunction()

	println("\nFunction: playWithPErson")
	playWithPErson()

	println("\nFunction: playWithRectangle")
	playWithRectangle()

	println("\nFunction: playWithColours")
	playWithColours()

	println("\nFunction: playWithEval")
	playWithEval()

	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
}

