/*
Ccmpiling Kotlin File
kotlinc KotlinCollections.kt -include-runtime -d collections.jar

Running Jar File
java -jar collections.jar
*/

// __________________________________________________
// DO FOLLOWING CODE! MOMENT DONE RAISE YOUR HANDS!!!

fun playWithKotlinCollections() {
	// Creating Collections Using Kotlin APIs
	//		It Uses Java Collections
	val set = hashSetOf( 11, 22, 55 )
	val list = arrayListOf( 11, 22, 55 )
	val map = hashMapOf(1 to "One", 7 to "Seven", 10 to "Ten", 50 to "Fifty")

	println( set.javaClass )	
	println( list.javaClass )
	println( map.javaClass )

	val strings = listOf("First", "Second", "Fourteenth")
	println( strings.javaClass )
	println( strings.last() )

	val numbers = setOf( 11, 14, 33 )
	println( numbers.javaClass )
	println( numbers.maxOrNull() )
}

// Function: playWithKotlinCollections
// class java.util.HashSet
// class java.util.ArrayList
// class java.util.HashMap
// class java.util.Arrays$ArrayList
// Fourteenth
// class java.util.LinkedHashSet
// 33

// __________________________________________________
// __________________________________________________
// __________________________________________________
// __________________________________________________
// __________________________________________________
// __________________________________________________
// __________________________________________________
// COMPLETE HANDS ON! MOMENT DONE RAISE YOUR FLAGS!!!

fun main() {
	println("\nFunction: playWithKotlinCollections")
	playWithKotlinCollections()

	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
}

/*
	https://codebunk.com/b/6251100617995/
	https://codebunk.com/b/6251100617995/
	https://codebunk.com/b/6251100617995/
*/
