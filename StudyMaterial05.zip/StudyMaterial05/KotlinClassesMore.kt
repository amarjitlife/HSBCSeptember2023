/*
Ccmpiling Kotlin File
kotlinc KotlinClassesMore.kt -include-runtime -d classesMore.jar

Running Jar File
java -jar classesMore.jar
*/

// __________________________________________________
// DO FOLLOWING CODE! MOMENT DONE RAISE YOUR HANDS!!!

open class Person( val firstName: String, val lastName: String ) {
	val fullName = "$firstName $lastName" 	//Kotlin Style Using Properties
	fun fullName() = "$firstName $lastName"
}

data class Subject(val name: String, val grade: Char, val points: Double, val credits: Double)
// error: this type has a constructor, and thus must be initialized here
// error: 'firstName' hides member of supertype 'Person' and needs 'override' modifier
// error: 'lastName' hides member of supertype 'Person' and needs 'override' modifier
// class Student( val firstName: String, val lastName: String ) : Person(firstName, lastName)
// Resusing Properties Defined In Person Class
//			  Only Specifity Signrature Of Cosntructor
open class Student( firstName: String, lastName: String ) : Person(firstName, lastName) {
	val passedSubjects : MutableList<Subject> = mutableListOf<Subject>()
	val failedSubjects : MutableList<Subject> = mutableListOf<Subject>()

	fun recordGrade( subject: Subject ) {
		if ( subject.grade == 'F' ) failedSubjects.add( subject )
		else passedSubjects.add( subject )
	} 

	open fun printGrades() {
		println("Grades Of : $fullName" )
		for( subject in passedSubjects ) println("\t$subject")
		for( subject in failedSubjects ) println("\t$subject")
	}
}

// __________________________________________________
// COMPLETE HANDS ON! MOMENT DONE RAISE YOUR FLAGS!!!

fun playWithClassesInheritance() {
	val gabbar1 = Person("Gabbar", "Singh")
	println( gabbar1.firstName )
	println( gabbar1.lastName )
	println( gabbar1.fullName )
	println( gabbar1.fullName() )

	val gabbar = Student("Gabbar", "Singh")
	val basanti = Student("Bansanti", "Only")
	val alice = Student("Alice", "Carol")

	println( gabbar.fullName )
	println( gabbar.fullName() )
	println( basanti.fullName )
	println( basanti.fullName() )
	println( alice.fullName )
	println( alice.fullName() )
}

// __________________________________________________
// COMPLETE HANDS ON! MOMENT DONE RAISE YOUR FLAGS!!!

fun playWithStudentGrades() {
	val gabbar = Student("Gabbar", "Singh")
	val basanti = Student("Bansanti", "Only")
	// val alice = Student("Alice", "Carol")
	
	val decoit  = Subject(name="Decoiti", grade='A', points = 10.0, credits = 4.0 )	
	val shooting= Subject(name="Shooting", grade='B', points = 9.0, credits = 3.0 )	
	val horseRiding  = Subject(name="Horse Riding", grade='C', points = 9.0, credits = 3.0 )	

	gabbar.recordGrade( decoit )
	gabbar.recordGrade( shooting )
	gabbar.recordGrade( horseRiding )

	val chitchat  = Subject(name="Chit Chatting", grade='A', points = 10.0, credits = 4.0 )	
	val dancing  = Subject(name="Dancing", grade='B', points = 8.0, credits = 3.0 )	
	val horseCart  = Subject(name="Horse Carting", grade='A', points = 9.0, credits = 4.0 )	

	basanti.recordGrade( chitchat )
	basanti.recordGrade( dancing )
	basanti.recordGrade( horseCart )

	gabbar.printGrades()
	basanti.printGrades()
}
// __________________________________________________
// COMPLETE HANDS ON! MOMENT DONE RAISE YOUR FLAGS!!!

data class Game(val name: String, val grade: Char, val points: Double, val credits: Double)

class StudentAthlete( firstName: String, lastName: String ) : Student( firstName, lastName ) {
	val gamesPlayed = mutableListOf<Game>()

	fun recordGame( game: Game ) = gamesPlayed.add( game )

	override fun printGrades() {
		super.printGrades()

		for( game in gamesPlayed ) println("\t$game")
	}	
}

// __________________________________________________

fun playWithStudentAthlete() {
	val gabbar = StudentAthlete("Gabbar", "Singh")
	val basanti = StudentAthlete("Bansanti", "Only")
	// val alice = Student("Alice", "Carol")
	
	val decoit  = Subject(name="Decoiti", grade='A', points = 10.0, credits = 4.0 )	
	val shooting= Game(name="Shooting", grade='B', points = 9.0, credits = 3.0 )	
	val horseRiding  = Game(name="Horse Riding", grade='C', points = 9.0, credits = 3.0 )	

	gabbar.recordGrade( decoit )
	gabbar.recordGame( shooting )
	gabbar.recordGame( horseRiding )

	val chitchat  = Subject(name="Chit Chatting", grade='A', points = 10.0, credits = 4.0 )	
	val dancing  = Game(name="Dancing", grade='B', points = 8.0, credits = 3.0 )	
	val horseCart  = Game(name="Horse Carting", grade='A', points = 9.0, credits = 4.0 )	

	basanti.recordGrade( chitchat )
	basanti.recordGame( dancing )
	basanti.recordGame( horseCart )

	gabbar.printGrades()
	basanti.printGrades()
}

// __________________________________________________

open class BandMember( firstName: String, lastName: String ) : Student(firstName, lastName) {
	// error: 'minimumPracticeTime' in 'BandMember' is final and cannot be overridden
	open val minimumPracticeTime : Int
		get() { return 2 }
}

class GuitarPlayer(firstName: String, lastName: String) : BandMember(firstName, lastName) {
	override val minimumPracticeTime : Int
		get() { return 3 }	
}

class FlutePlayer(firstName: String, lastName: String) : BandMember(firstName, lastName) {
	override val minimumPracticeTime : Int
		get() { return 4 }	
}

fun playWithTypeCheck() {
	val g : GuitarPlayer = GuitarPlayer("Jimmy", "Hendrik")

	println( g.fullName )

	if ( g is GuitarPlayer ) println("g of Type GuitarPlayer")
	if ( g is BandMember ) println("g of Type BandMember")
	if ( g is Student ) println("g of Type Student")
	if ( g is Person ) println("g of Type Person")

	val refererence1 = g
	val refererence2: BandMember = g
	val refererence3: Student = g 
	val refererence4: Person = g 

	if ( refererence1 is GuitarPlayer ) println("refererence1 of Type GuitarPlayer")
	if ( refererence1 is BandMember ) println("refererence1 of Type BandMember")
	if ( refererence1 is Student ) println("refererence1 of Type Student")
	if ( refererence1 is Person ) println("refererence1 of Type Person")

	if ( refererence2 is GuitarPlayer ) println("refererence2 of Type GuitarPlayer")
	if ( refererence2 is BandMember ) println("refererence2 of Type BandMember")
	if ( refererence2 is Student ) println("refererence2 of Type Student")
	if ( refererence2 is Person ) println("refererence2 of Type Person")

	val shakira = BandMember("Shakira", "Isabel")
	if ( shakira is GuitarPlayer ) println("shakira Of Type GuitarPlayer")
	if ( shakira is BandMember )   println("shakira Of Type BandMember")
	if ( shakira is Student ) 	   println("shakira Of Type Student")
	if ( shakira is Person ) 	   println("shakira Of Type Person")

	val milkha = StudentAthlete("Milkha", "Singh")
	if ( milkha is Student ) 	  	println("milkha Of Type Student")
	if ( milkha is Person ) 	  	println("milkha Of Type Person")
	if ( milkha is StudentAthlete ) println("milkha Of Type StudentAthlete")
	// error: incompatible types: GuitarPlayer and StudentAthlete
	// if ( milkha is GuitarPlayer ) println("milkha Of Type GuitarPlayer")
	// error: incompatible types: BandMember and StudentAthlete	
	// if ( milkha is BandMember )   println("milkha Of Type BandMember")
}

// __________________________________________________
// COMPLETE HANDS ON! MOMENT DONE RAISE YOUR FLAGS!!!

class Client1( val name: String, val postalCode: Int )  {
	override fun toString() : String {
		return "Client1(name=$name, postalCode=$postalCode)"
	}
}

fun playWithClient1() {
	val gabbar = Client1("Gabbar Singh", 999998 )
	println( gabbar.name )
	println( gabbar.postalCode )

	println( gabbar ) // gabbar.toString()
	
	val gabbarDuplicate = Client1("Gabbar Singh", 999998 )
	println( gabbarDuplicate.name )
	println( gabbarDuplicate.postalCode )
	println( gabbarDuplicate ) // gabbar.toString()

	println( gabbar == gabbarDuplicate )
}


// __________________________________________________
// COMPLETE HANDS ON! MOMENT DONE RAISE YOUR FLAGS!!!

class Client2( val name: String, val postalCode: Int )  {
	override fun toString() : String {
		return "Client2(name=$name, postalCode=$postalCode)"
	}

	override fun equals( other: Any? ) : Boolean {
		if ( other == null  || other !is Client2 ) return false
		return name == other.name && postalCode == other.postalCode
	}
}

fun playWithClient2() {
	val gabbar = Client2("Gabbar Singh", 999998 )
	println( gabbar ) // gabbar.toString()
	
	val gabbarDuplicate = Client2("Gabbar Singh", 999998 )
	println( gabbarDuplicate ) // gabbar.toString()

	println( gabbar == gabbarDuplicate )
}

//_____________________________________________________________________
//
//	Java Object Class Documentation Link
// 	https://docs.oracle.com/javase/8/docs/api/java/lang/Object.html
//		Study toString()	Function
//		Study equal() 		Function 
//		Study hashCode() 	Function
//_____________________________________________________________________

// Data Classes
//		Compiler Will Generate Following Functions Code
//		1. toString() 	Method With Code
//				Includes All The Properties
//		2. equals() 	Method With Code
//				Compares  All The Properties
//		3. hashCode() 	Method Code
//				Generates HashCode On All Immutable Properties
//_____________________________________________________________________

data class Client3( val name: String, val postalCode: Int )  

fun playWithClient3() {
	val gabbar = Client3("Gabbar Singh", 999998 )
	println( gabbar ) // gabbar.toString()
	
	val gabbarDuplicate = Client3("Gabbar Singh", 999998 )
	println( gabbarDuplicate ) // gabbar.toString()

	println( gabbar == gabbarDuplicate )
}

// __________________________________________________

// Data Classes
//		Compiler Will Generate Following Functions Code
//		1. equals() 	Method With Code
//				Compares  All The Properties
//		2. hashCode() 	Method Code
//				Generates HashCode On All Immutable Properties

// Will NOT generate toString Method As Programmer Provided Custom Implementation
data class Client4( val name: String, val postalCode: Int )  {
	override fun toString() : String { // Custom Method Used Rather Than Compiler Generates 
		return ">>> Client4(name=$name, postalCode=$postalCode)"
	}
}

fun playWithClient4() {
	val gabbar = Client4("Gabbar Singh", 999998 )
	println( gabbar ) // gabbar.toString()
	
	val gabbarDuplicate = Client4("Gabbar Singh", 999998 )
	println( gabbarDuplicate ) // gabbar.toString()

	println( gabbar == gabbarDuplicate )
}

// __________________________________________________

//Object Classes 
//		Singleton Classes
//		Having Only One Instance Possible
//			and Instance Name Is Same A Class Name
object India {
	val name = "Bharat"
	var states = 32

	fun raiseNationalFlag() {
		println("Raising India Flags!!!")
	}
}

fun playWithSingleton() {
	println( India.name )
	println( India.states )

	India.raiseNationalFlag()
}

// __________________________________________________
/*
class SingletonExample {
    //  Class/Type Member
    private static SingletonExample instance =  null;
    // private constructor to avoid client applications using the constructor
    private SingletonExample(){}

    // CLass/Type Member       
    public static SingletonExample getInstance() {
        if ( instance == null )
            instance new SingletonExample();
        return instance;
    }

    public void doDance() { System.out.println("Doing Dance"); }
}
*/
// Compiler Will Generate Above Code For Following Class
object SingletonExample {
	fun doDance() {
		println("Doing Dance")		
	}
}

fun playWithSingleonAgain() {
	SingletonExample.doDance()
}

// __________________________________________________
// COMPLETE HANDS ON! MOMENT DONE RAISE YOUR FLAGS!!!

abstract class Mammal( val name: String, val birthDate: String) {
	abstract fun consumeFood()
	
	fun doDance() {
		println("Mammal Doing Dance!!!")
	}
}

class Human( name: String, birthDate: String ) : Mammal( name, birthDate ) {
	override fun consumeFood() {
		println("Human Consuming Food...")
	}

	fun createBirthCertificate() = println("Birth Certificate Created!!!")
}

fun playWithAbstractClasses() {
	// val mamal = Mammal()
	// println( mam.name )
	val katrina = Human("Katrina Kaif", "16-July-1983")
	katrina.consumeFood()
	katrina.createBirthCertificate()
	katrina.doDance()

	println( katrina is Human )	
	println( katrina is Mammal )	
}

// __________________________________________________
// COMPLETE HANDS ON! MOMENT DONE RAISE YOUR FLAGS!!!

// Following Both Definitions Are Equivalent

// Defininng		Primary Constructor :
//		Will Take Two Arguments firstName And lastName Of Type String
class PersonAgain1( val firstName: String, val lastName: String ) {
	val fullName = "$firstName $lastName"
}

// Defininng		Primary Constructor :
//		Will Take Two Arguments firstName And lastName Of Type String
//		constructor Keyword Is Optional In Primary Constructor
class PersonAgain2 constructor( val firstName: String, val lastName: String ) {
	val fullName = "$firstName $lastName"
}

fun playWithPersonAgain() {
	val person1 = PersonAgain1( "Gabbar", "Singh")
	println( person1.fullName )

	val person2 = PersonAgain2( "Gabbar", "Singh")
	println( person2.fullName )
}

// __________________________________________________

enum class Color { RED, GREEN, BLUE, WHITE, BLACK }

class ShapeDesign1 {
	var boundaryColor : Color
	var fillColor: Color

	constructor() {
		this.boundaryColor = Color.BLACK
		this.fillColor     = Color.WHITE
	}

	constructor( boundaryColor: Color ) {
		this.boundaryColor = boundaryColor
		this.fillColor     = Color.WHITE		
	}

	// Following Constructor Makes Constructor Overloading Ambiguous
	//		Because Overloading Works Based On 
	//			Number of Arguments and Type Of Arguments
	// constructor( fillColor: Color ) {
	// 	this.boundaryColor = Color.BLACK
	// 	this.fillColor     = fillColor		
	// }
	constructor( boundaryColor: Color, fillColor: Color ) {
		this.boundaryColor = boundaryColor
		this.fillColor     = fillColor				
	}

	override fun toString() = "Shape(boundaryColor=$boundaryColor, fillColor=$fillColor)"
}

// DESIGN PRACTICES
// SECONDARY CONSTRUCTORS DESIGN
// 		1. All Constructors Within Class Should Call Constructor Within
//				Constructor Which Initialises Object Fully
//				i.e. Constructor Which Takes Maximum Number Of Arguments
//				Let's Call It FULL Constructor
//		2.FULL Constructor From Child Class Should Call FULL Constructor From Parent Class

class ShapeDesign2 {
	var boundaryColor : Color
	var fillColor: Color

	// Seconday Constructors
	constructor() : this( Color.BLACK, Color.WHITE ) {
		// this.boundaryColor = Color.BLACK
		// this.fillColor     = Color.WHITE
	}

	// Seconday Constructors	
	constructor( boundaryColor: Color ) : this( boundaryColor, Color.WHITE ){
		// this.boundaryColor = boundaryColor
		// this.fillColor     = Color.WHITE		
	}

	// Following Constructor Makes Constructor Overloading Ambiguous
	//		Because Overloading Works Based On 
	//			Number of Arguments and Type Of Arguments
	// constructor( fillColor: Color ) {
	// 	this.boundaryColor = Color.BLACK
	// 	this.fillColor     = fillColor		
	// }
	// FULL Constructor
	constructor( boundaryColor: Color, fillColor: Color ) {
		this.boundaryColor = boundaryColor
		this.fillColor     = fillColor				
	}

	override fun toString() = "Shape(boundaryColor=$boundaryColor, fillColor=$fillColor)"
}

// DESIGN PRACTICE
// Constructor Design Choice
//		Always Prefer Primary Constructor with Default Arguments
//			Over Constructor Overloading
//				  Constructor With Default Arguments

class ShapeDesign3 constructor( var boundaryColor: Color = Color.BLACK, var fillColor: Color = Color.WHITE ) {
	override fun toString() = "Shape(boundaryColor=$boundaryColor, fillColor=$fillColor)"
}

fun playWithShape() {
	val shape1 = ShapeDesign1()
	val shape2 = ShapeDesign1( boundaryColor = Color.RED )
	val shape3 = ShapeDesign1( boundaryColor = Color.RED, fillColor = Color.GREEN )
	// val shape4 = ShapeDesign1( fillColor = Color.GREEN )

	println( shape1 )
	println( shape2 )
	println( shape3 )
	// println( shape4 )

	val shape11 = ShapeDesign3()
	val shape12 = ShapeDesign3( boundaryColor = Color.RED )
	val shape13 = ShapeDesign3( boundaryColor = Color.RED, fillColor = Color.GREEN )
	val shape14 = ShapeDesign3( fillColor = Color.GREEN )

	println( shape11 )
	println( shape12 )
	println( shape13 )
	println( shape14 )
}

// __________________________________________________

// DESIGN PRACTICES
// SECONDARY CONSTRUCTORS DESIGN
// 		1. All Constructors Within Class Should Call Constructor Within
//				Constructor Which Initialises Object Fully
//				i.e. Constructor Which Takes Maximum Number Of Arguments
//				Let's Call It FULL Constructor
//		2.FULL Constructor From Child Class Should Call FULL Constructor From Parent Class

open class Shape {
	var boundaryColor : Color
	var fillColor: Color

	// Seconday Constructors
	constructor() : this( Color.BLACK, Color.WHITE ) {
		// this.boundaryColor = Color.BLACK
		// this.fillColor     = Color.WHITE
	}

	// Seconday Constructors	
	constructor( boundaryColor: Color ) : this( boundaryColor, Color.WHITE ){
		// this.boundaryColor = boundaryColor
		// this.fillColor     = Color.WHITE		
	}

	// Following Constructor Makes Constructor Overloading Ambiguous
	//		Because Overloading Works Based On 
	//			Number of Arguments and Type Of Arguments
	// constructor( fillColor: Color ) {
	// 	this.boundaryColor = Color.BLACK
	// 	this.fillColor     = fillColor		
	// }
	// FULL Constructor
	constructor( boundaryColor: Color, fillColor: Color ) {
		this.boundaryColor = boundaryColor
		this.fillColor     = fillColor				
	}

	override fun toString() = "Shape(boundaryColor=$boundaryColor, fillColor=$fillColor)"
}

class Circle : Shape {
	var radius: Int

	constructor( boundaryColor : Color ) : this(boundaryColor, Color.WHITE, 0) {
		// this.boundaryColor  = boundaryColor
		// this.fillColor 		= Color.WHITE
		// this.radius 		= 0 
	}

	constructor( boundaryColor: Color, fillColor: Color ): this(boundaryColor, fillColor, 0) {
		// this.boundaryColor 	= boundaryColor
		// this.fillColor     	= fillColor
		// this.radius 		= 0 			
	}	

	constructor( boundaryColor: Color, fillColor: Color, radius: Int ) : super(boundaryColor, fillColor){
		this.boundaryColor 	= boundaryColor
		this.fillColor     	= fillColor
		this.radius 		= radius
	}		

	override fun toString() = "Circle(boundaryColor=$boundaryColor, fillColor=$fillColor, radius=$radius)"
}

fun playWithShapeAndCircle() {
	val shape1 = Shape( Color.RED )
	val shape2 = Shape( Color.RED, Color.GREEN )

	println( shape1 )
	println( shape2 )

	val circle1 = Circle( Color.RED )
	val circle2 = Circle( Color.RED, Color.GREEN )
	val circle3 = Circle( Color.RED, Color.GREEN, 99 )

	println( circle1 )
	println( circle2 )
	println( circle3 )
}

// __________________________________________________

fun playWithLocalFunctionsAndLocalClasses() { // Enclosing Context A
	var something = 10
	println("Accessing Outside: $something")	

	// Local Function: Function Defined Inside Function
	fun doSomething() { // Enclosed Context B
		println("Local Function doSomething Called!")
		println("1. Accessing Inside: $something")
		something = 111
	}
	println("1. Accessing Outside: $something")

	// Local Class: Class Defined Inside Function
	class Person(val firstName: String, val lastName: String) {  // Enclosing Context C
																 // Enclosed Context w.r.t. A															 
		val somethingAgain = 90
		fun doDance() = println("Dancing With Charm!")  // Enclosed Context w.r.t C
		fun doSomething() { // Enclosed Context w.r.t C
			println("2. Accessing Inside: $something")
			something = somethingAgain
		}
		override fun toString() = "Person(firstName=$firstName, lastName=$lastName)" // Enclosed Context w.r.t. C
	}

	doSomething()
	println("2. Accessing Outside: $something")

	val person = Person( "Gabbar", "Singh" )
	println( person )
	person.doDance()
	person.doSomething()
	println("3. Accessing Outside: $something")
}

// __________________________________________________

data class Privilege( val id: Int, val name: String )
// Property Visibility
//     Default Visibility Is Public i.e. Accessible Inside and Outside Of Defining Class
//     Private Visibility Accessible Only Inside Defining Class
//     Protected Visibility Accessible Inside Defining Class And Child Classes Of It
open class User(val firstName: String, val lastName: String, protected var age: Int, private var aadharCard: Int ) 

class PrivilegedUser(firstName: String, lastName: String, age: Int, aadharCard: Int) : User(firstName, lastName, age, aadharCard) {
    // Private To PrivilegeUser Class Only
    //      Cann't Be Accessed Outside Using Object Of PrivilegeUser Class
    private val privileges = mutableListOf<Privilege>()

    fun addPrivilege(privilege: Privilege) {
        privileges.add( privilege )
    }

    fun printPrivileges() {
        for ( privilege in privileges ) {
            println( "    $privilege" )
        }
    }

    fun details() : String {
        // error: cannot access 'aadharCard': 
        // it is invisible (private in a supertype) in 'PrivilegedUser'
        // return "$firstName $lastName $aadharCard"
        return "Name : $firstName $lastName, Age: $age"
    }
}

fun playWithPrivilegedUser() {
    val privilegedUser = PrivilegedUser(firstName = "Alice", lastName = "Carols", age = 21, aadharCard = 9999 )
    val invisiblePrivilege = Privilege( id = 11, name = "Can Become Invisible")
    val immortalPrivilege  = Privilege( id = 22, name = "Can Become Immortal")
    privilegedUser.addPrivilege( invisiblePrivilege )
    privilegedUser.addPrivilege( immortalPrivilege )
    println( privilegedUser.details() )
    privilegedUser.printPrivileges()
    // println( privilegedUser.privileges )
    // privilegedUser.privileges.add( Privilege( -99, "Something Useless Power"))
    // println( privilegedUser.privileges )
}

// __________________________________________________

// interface Expr
sealed class Expr {
	// Class Defined Inside Class
	class Num( val value: Int ) : Expr()
	class Sum( val left: Expr, val right: Expr ) : Expr()
}

fun evalulate( expression: Expr ) : Int = when ( expression ) { 
	is Expr.Num  -> 	expression.value
	is Expr.Sum 	-> 	evalulate( expression.left ) + evalulate( expression.right )
	// else  	->  throw IllegalArgumentException("Unknown Expression!!!")
}

fun playWithEvaluate() {
	var result : Int
	result = evalulate( Expr.Sum( Expr.Num( 100 ), Expr.Num( 200 )) )
	println( "Result: $result" )

	result = evalulate( Expr.Sum( Expr.Sum( Expr.Num( 100 ), Expr.Num( 200 )), Expr.Num( 1000 ) ) )
	println( "Result: $result" )
}

// __________________________________________________
// Classes Defined Inside Another Class
sealed class Geometry {
	class Circle(val radius: Int) : Geometry()
	class Square(val side: Int) : Geometry()
	class Unknown(val size: Int) : Geometry()
}
// DESIGN 1
fun sizeOfGeometry1( geometry: Geometry ) : Any {
	return when( geometry ) {
		is Geometry.Circle -> geometry.radius
		is Geometry.Square -> geometry.side
		else -> "Unknown Shape"
	}
}
// DESIGN 2
fun sizeOfGeometry2( geometry: Geometry ) = when( geometry ) {
	is Geometry.Circle -> geometry.radius
	is Geometry.Square -> geometry.side
	else -> "Unknown Shape"
}
// DESIGN 1 and DESIGN 2 BOTH ARE SAME
// DESIGN 3: BETTER DESIGN
fun sizeOfGeometry3( geometry: Geometry ) : Int = when( geometry ) {
	is Geometry.Circle -> geometry.radius
	is Geometry.Square -> geometry.side
	is Geometry.Unknown -> geometry.size
}

fun playWithGeometries() {
	val circle1 = Geometry.Circle( 10 )
	val circle2 = Geometry.Circle( 20 )
	println( sizeOfGeometry1( circle1 ) )
	println( sizeOfGeometry1( circle2 ) )

	val square1 = Geometry.Square( 11 )
	val square2 = Geometry.Square( 22 )
	println( sizeOfGeometry1( square1 ) )
	println( sizeOfGeometry1( square2 ) )

	println( sizeOfGeometry3( circle1 ) )
	println( sizeOfGeometry3( circle2 ) )
	println( sizeOfGeometry3( square1 ) )
	println( sizeOfGeometry3( square2 ) )
}


// __________________________________________________
// __________________________________________________
// __________________________________________________
// __________________________________________________
// COMPLETE HANDS ON! MOMENT DONE RAISE YOUR FLAGS!!!

fun main() {
	println("\nFunction: playWithClassesInheritance")
	playWithClassesInheritance()

	println("\nFunction: playWithStudentGrades")
	playWithStudentGrades()

	println("\nFunction: playWithStudentAthlete")
	playWithStudentAthlete()

	println("\nFunction: playWithTypeCheck")
	playWithTypeCheck()

	println("\nFunction: playWithClient1")
	playWithClient1()

	println("\nFunction: playWithClient2")
	playWithClient2()

	println("\nFunction: playWithClient3")
	playWithClient3()

	println("\nFunction: playWithClient4")
	playWithClient4()

	println("\nFunction: playWithSingleton")
	playWithSingleton()

	println("\nFunction: playWithSingleonAgain")
	playWithSingleonAgain()

	println("\nFunction: playWithAbstractClasses")
	playWithAbstractClasses()

	println("\nFunction: playWithPersonAgain")
	playWithPersonAgain()

	println("\nFunction: playWithShape")
	playWithShape()

	println("\nFunction: playWithShapeAndCircle")
	playWithShapeAndCircle()

	println("\nFunction: playWithLocalFunctionsAndLocalClasses")
	playWithLocalFunctionsAndLocalClasses()

	println("\nFunction: playWithPrivilegedUser")
	playWithPrivilegedUser()

	println("\nFunction: playWithEvaluate")
	playWithEvaluate()

	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
}

/*
	https://codebunk.com/b/6251100617995/
	https://codebunk.com/b/6251100617995/
	https://codebunk.com/b/6251100617995/
	https://codebunk.com/b/6251100617995/
*/
