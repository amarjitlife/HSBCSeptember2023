/*
Ccmpiling Kotlin File
kotlinc KotlinClasses.kt -include-runtime -d classes.jar

Running Jar File
java -jar classes.jar
*/

// __________________________________________________
// DO FOLLOWING CODE! MOMENT DONE RAISE YOUR HANDS!!!

// In Java
//		Classes Are Open By Default
//			Can Be Inherited From
//		Member Functions Are Also Open By Default
//			Can Be Overridden

// In Kotlin
//		Classes Are Final By Default
//			Cannot Be Inherited From
//		Member Functions Are Also Final By Default
//			Cannot Be Overriden

open class View {
	// error: 'click' in 'View' is final and cannot be overridden
	// fun click() = println("View Clicked!")
	open fun click() = println("View Clicked!")
}

// Inheriting Button From View Class
// error: this type has a constructor, and thus must be initialized here
// class Button: View {
class Button: View() {
	override fun click() = println("Button Clicked!")
	fun magic() 	= println("Button Magic.")
	fun cricket() 	= println("Button Cricket.")
}

fun playWithInheritance() {
	val view  = View()
	view.click()

	val view1: View  = View()
	view1.click()

	val button= Button()
	button.click()
	button.magic()

	val buttonAgain: Button= Button()
	buttonAgain.click()
	buttonAgain.magic()

	// Button Object Views With Parent Perceptives
	val viewAgain : View = Button()
	viewAgain.click()
	//  error: unresolved reference: magic
	// viewAgain.magic()
	// viewAgain.cricket()

	val viewKiddu : View = Button()
	viewKiddu.click()

	val bringKidduBack = viewKiddu as Button
	bringKidduBack.click()
	bringKidduBack.magic()
	bringKidduBack.cricket()
}

// __________________________________________________
// COMPLETE HANDS ON! MOMENT DONE RAISE YOUR FLAGS!!!

open class View1 {
	open fun click() = println("View1 Clicked!")
}

class Button1: View1() {
	override fun click() = println("Button1 Clicked!")
	fun magic() 	= println("Button1 Magic.")
}

// error: modifier 'open' is not applicable to 'top level function'
// open fun View1.showOff() 	= println("View1 Showoff!")
// error: modifier 'override' is not applicable to 'top level function'
// override fun Button1.showOff() 	= println("Button1 Showoff!")

fun View1.showOff() 	= println("View1 Showoff!")
fun Button1.showOff() 	= println("Button1 Showoff!")

fun playWithInheritanceAgain() {
	val view  = View1()
	view.click()
	view.showOff()

	val button= Button1()
	button.click()
	button.magic()
	button.showOff()

	// Button Object Views With Parent Perceptives
	val viewAgain : View1 = Button1()
	viewAgain.click()
	// viewAgain.magic()
	viewAgain.showOff() // Extension Functions Doesn't Participats In Overriding
}

// __________________________________________________
// COMPLETE HANDS ON! MOMENT DONE RAISE YOUR FLAGS!!!

// In Kotlin
// 		Interfaces And Interface Members Are Open By Default

// DESIGN PRINCIPLE
//		DESIGN TOWARDS INTERFACES RATHER THAN CONCRETE CLASSES

// Interfaces Defines 
// 		What To Do?
interface Clickable2 {
	fun click()
}

// Concrete Class
// 		How To Do, When To Do, WHich Way To DO....?

// Class Implementing Interface
class Button21 : Clickable2 {
	override fun click() = println("Button21 Clicked!")
}

class Button22 : Clickable2 {
	override fun click() = println("Button22 Clicked!")
}

fun playWithInterfaces() {
	val button1 = Button21()
	button1.click()

	val button2 = Button22()
	button2.click()
}

// __________________________________________________
// COMPLETE HANDS ON! MOMENT DONE RAISE YOUR FLAGS!!!

interface Clickable3 {
	fun click()
	// showOff() with Default Implementations : Should Be Used In Rarest Rare Scenarios
	fun showOff() = println("Interface Clickable3 : showOff called ") 
}

interface Focusable3 {
	fun setFocus( status: Boolean ) = println( "I ${ if (status) "GOT" else "LOST" } FOCUS.")
	fun showOff() = println("Interface Focusable3 : showOff called ") 
}

class Button3 : Clickable3, Focusable3 {
	override fun click() = println("Button3 Click Called!")
	override fun showOff() {
		 // error: many supertypes available, please specify the 
		// one you mean in angle brackets, e.g. 'super<Foo>'
		// super.showOff()
		super<Clickable3>.showOff()
		super<Focusable3>.showOff()
	}
}

// error: class 'Button3' must override public open fun showOff(): Unit 
// 		defined in Clickable3 because it inherits multiple interface methods of it
fun playWithInterfacesAgain() {
	val button1 = Button3()
	button1.click()
	button1.setFocus( true )
	button1.showOff()
}

// __________________________________________________
// __________________________________________________
// __________________________________________________
// __________________________________________________
// __________________________________________________
// __________________________________________________
// __________________________________________________
// COMPLETE HANDS ON! MOMENT DONE RAISE YOUR FLAGS!!!

fun main() {
	println("\nFunction: playWithInheritance")
	playWithInheritance()

	println("\nFunction: playWithInheritanceAgain")
	playWithInheritanceAgain()

	println("\nFunction: playWithInterfaces")
	playWithInterfaces()

	println("\nFunction: playWithInterfacesAgain")
	playWithInterfacesAgain()

	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
}

/*
	https://codebunk.com/b/6251100617995/
	https://codebunk.com/b/6251100617995/
	https://codebunk.com/b/6251100617995/
*/
