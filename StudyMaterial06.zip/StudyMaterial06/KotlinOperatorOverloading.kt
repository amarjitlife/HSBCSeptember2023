/*
Ccmpiling Kotlin File
kotlinc KotlinOperatorOverloading.kt -include-runtime -d operators.jar

Running Jar File
java -jar operators.jar
*/

import java.math.BigDecimal

// __________________________________________________
// DO FOLLOWING CODE! MOMENT DONE RAISE YOUR HANDS!!!

data class Point(val x: Int, val y: Int) {
	operator fun plus(other: Point) : Point {
		val xx = x + other.x
		val yy = y + other.y

		return Point(xx, yy)	
	}

	override fun equals(other: Any?) : Boolean {
		// if ( other == this ) return true
		if ( other == null || other !is Point ) return false
		return other.x == x && other.y == y
	}	
}

operator fun Point.times( scalar : Int ) : Point {
	return Point( x * scalar , y * scalar )
}

operator fun Point.unaryMinus() : Point {
	return Point( -x, -y )
}

fun playWithPoints() {
	val point1 = Point(10, 20)
	val point2 = Point(20, 30)

	println( point1 )
	println( point2 )

	val xx = point1.x + point2.x
	val yy = point1.y + point2.y

	val point30 = Point(xx, yy)
	println( point30 )

	// Using Overloaded + Operator
	val point31 = point1 + point2 // point1.plus( point2 )
	println( point31 )	

	println( point1 * 5 ) // point1.times( 5 )
	println( point2 * 10 )// point1.times( 10 )

	println( -point1 ) // point1.unaryMinus()
	println( -point2 ) // point2.unaryMinus()

	println( point1 == point2 )
	println( point1 != point2 )
}

// __________________________________________________

// import java.math.BigDecimal

operator fun BigDecimal.inc() = this + BigDecimal.ONE 

fun playWithUniaryIncrementOperator() {
	var bigZero = BigDecimal.ZERO

	println( bigZero )
	println( bigZero++ ) // bigZero.inc()
	println( ++bigZero ) // bigZero.inc()
}

//_____________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE FLAG!!!

data class Point1(val x: Int, val y: Int ) 

operator fun Point1.get(index: Int) : Int {
	return when( index ) {
		0 -> x
		1 -> y
		else -> throw IndexOutOfBoundsException("Index Out Of Range...")
	}
}

fun playWithPointsAgain() {
	val point1 = Point1(10, 20)
	val point2 = Point1(11, 22)

	println( point1[0] ) //point1.get(0)
	println( point1[1] ) //point1.get(1)

	println( point2[0] )
	println( point2[1] )
}

//_____________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE FLAG!!!

data class MutablePoint(var x: Int, var y: Int ) 

operator fun MutablePoint.get(index: Int) : Int {
	return when( index ) {
		0 -> x
		1 -> y
		else -> throw IndexOutOfBoundsException("Index Out Of Range...")
	}
}

operator fun MutablePoint.set(index: Int, value: Int) {
	when( index ) {
		0 -> x = value
		1 -> y = value
		else -> throw IndexOutOfBoundsException("Index Out Of Range...")
	}
}

fun playWithMutablePoint() {
	val point1 = MutablePoint(10, 20)
	val point2 = MutablePoint(11, 22)

	println( point1[0] ) // point1.get(0)
	println( point1[1] ) // point1.get(1)
	point1[0] = 100  	 // point1.set(0, 100)
	point1[1] = 200 	 // point1.set(1, 200)	
	println( point1[0] )
	println( point1[1] )

	println( point2[0] )
	println( point2[1] )
	point2[0] = 111
	point2[1] = 222
	println( point2[0] )
	println( point2[1] )

}

//_____________________________________________________
// COMPLETE HANDS ON! MOMENT DONE RAISE YOUR FLAGS!!!

data class Rectangle(val upperLeft: Point, val lowerRight: Point)

operator fun Rectangle.contains(point: Point): Boolean {
    return point.x in upperLeft.x until lowerRight.x &&
           point.y in upperLeft.y until lowerRight.y
}

fun playWithOperatorIn() {
	val point1 = Point(10, 20)
	val point2 = Point(100, 200)
	val point  = Point(50, 50)

	val rectangle = Rectangle( point1, point2 )

	println( point in rectangle ) // rectangle.contains( point )

	val point11 = Point(20, 10)
	val point22 = Point(200, 100)

	val rectangle1 = Rectangle( point11, point22 )
	println( point in rectangle1 ) // rectangle.contains( point )
}

// __________________________________________________
// __________________________________________________
// __________________________________________________
// __________________________________________________
// __________________________________________________
// COMPLETE HANDS ON! MOMENT DONE RAISE YOUR FLAGS!!!

fun main() {
	println("\nFunction: playWithPoints")
	playWithPoints()

	println("\nFunction: playWithUniaryIncrementOperator")
	playWithUniaryIncrementOperator()

	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
}
/*
https://codebunk.com/b/6251100617995/
https://codebunk.com/b/6251100617995/
https://codebunk.com/b/6251100617995/
*/