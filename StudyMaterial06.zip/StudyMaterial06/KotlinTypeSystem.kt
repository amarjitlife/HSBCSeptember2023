/***
kotlinc KotlinTypeSystem.kt -include-runtime -d typesystem.jar
java -jar typesystem.jar 
***/
package learnKotlin

//_____________________________________________________________________
// In Java/C++ : All References Are Nullable By Default
// Human h = new Human();
// h = null;

// In Kotlin
//		Nullable Types and Non Nullable Types
//		By Default 
//			In Kotlin All Types Are Non Nullable

//		To Store null
//			Explicitly Make Type Nullable
//			Every Non Nullable Type Have Corresponding Nullable Type

//_____________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE FLAG!!!

fun playWithNullabilityAndNonNullability() {
	// String, Int, Float, Double etc... Are NON NULLABLE Types
	//		i.e. You CAN'T Assign null Value To These Types Variables
	var name: String = "Alice Carol"
	var age: Int = 30
	var occupation: String = "Software Engineer"

	println("$name $age $occupation")
	name = "Alice Carol Mcmillan"
	age = 40
	age = age + 1
	occupation = "Sr. Software Engineer"
	println("$name $age $occupation")	

	// Following 3 Lines Of Code Will Give Compilation Error
	// name = null  		// error: null can not be a value of a non-null type String
	// age = null 	 		// error: null can not be a value of a non-null type Int
	// occupation = null 	// error: null can not be a value of a non-null type String

	// Nullabe Types Are Also Called Optional Types
	// String?, Int?, Float?, Double? etc... Are NULLABLE Types
	//		i.e. You CAN Assign null Value To These Types Variables
	var name1: String? = "Alice Carol"
	var age1: Int? = 30
	var occupation1: String? = "Software Engineer"

	println("$name1 $age1 $occupation1")
	name1 = "Alice Carol Mcmillan"
	age1 = 40
	age1 = age1 + 1
	occupation1 = "Sr. Software Engineer"
	println("$name1 $age1 $occupation1")	

	name1 = null  		
	age1 = null 	 	
	occupation1 = null 	
	println("$name1 $age1 $occupation1")
}

//_____________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE FLAG!!!

fun playWithNullabilityAndNonNullabilityAgain() {
	var authorName: String? = "Joe Howard"
	var authorAge: Int? = 24

	println(authorName)
	println(authorAge)

	// error: operator call corresponds to a dot-qualified call 
	// 'authorAge.plus(1)' which is not allowed on a nullable receiver 'authorAge'.
	// val ageAfterBirthday = authorAge + 1 	// authorAge.plus(1)

	// error: only safe (?.) or 
	// non-null asserted (!!.) calls are allowed on a 
	// nullable receiver of type Int?
	// ?. is Safe Calls Operator

	// Good Practice
	// if ( authorAge != null )
	// 	val ageAfterBirthday = authorAge.plus(1)
	// else
		// val ageAfterBirthday = null

	// BAD Practice
	// val ageAfterBirthday = authorAge.plus(1)

	val ageAfterBirthday0 = authorAge?.plus(1)
   	// Compiler Will Generate Following Code For Above Line Of Code
    // if ( authorAge != null )
	// 	val ageAfterBirthday = authorAge.plus(1)
	// else
	// 	val ageAfterBirthday = null

	println("After their next birthday, author will be $ageAfterBirthday0")

	// !! Not Recommended,  It's Used In Rarest Rare Scenarios 
	val ageAfterBirthday1 = authorAge!! + 1    
	println("After their next birthday, author will be $ageAfterBirthday1")

	authorAge = null
	println("After two birthdays, author will be $authorAge")
	// val ageAfterBirthday2 = authorAge!! + 1    

	var nonNullableAuthor: String = ""
	var nullableAuthor: String? = ""

	if (authorName != null) {
		nonNullableAuthor = authorName
	} else {
		nullableAuthor = authorName
	}

	println(nonNullableAuthor)
	println(nullableAuthor)

	// Nullable Types Members Cann't Be Accessed Using . Operator
	//		Use ?. or !! Operator

	// error: only safe (?.) or non-null asserted (!!.) calls are allowed 
	// on a nullable receiver of type String?
	// var nameLength = authorName.length
 
	// ?. is Safe Calls Operator
	var nameLength = authorName?.length
	// Above Line Of Code Is Equvalent To Following Line Of Code
	// 		if (authorName != null) authorName else null
	println("Author's name has length $nameLength.")

	val nameLengthPlus5 = authorName?.length?.plus(5)
	// Compiler Will Generate Following Code For Above Line  
	// if ( authorName != null ) {
	// 	if ( authorName.length != null ) {
	// 		nameLengthPlus5 = authorName.length.plus(5)
	// 	} else {
	// 		nameLengthPlus5 = null
	// 	}
	// } else {
	// 	nameLengthPlus5 = null
	// }
	println("Author's name length plus 5 is $nameLengthPlus5.")
}

//_____________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE FLAG!!!

fun playWithElvisOperator() {	
	var something: String? = "Good Morning!"
	println(something)
	// something = null
	// println(something)

	// Coding Style 1
	// Nullable Types Data Must Accessed After Checking For null Value
	if (something != null ) {
		val upperValue = something.uppercase()
		println("$upperValue")
	} else {
		println("It Contains >>> Null Value...")
	}

	// Coding Style 2 
	val upperSomething0 = if (something != null) something else "" 
	
	// Coding Style 3 Using Elvis Operator 
	// ?: is Called Elvis Operator
	//		Default Values Written After This
	val upperSomething1 = something ?: "" // ?: DEAFULT VALUE
	// Above Line Of Code Is Equivalent To if (something != null) something else "" 

	println( upperSomething0.uppercase() )
	println( upperSomething1.uppercase() )

	var nullableValue: Int? = 10
	
	var mustHaveValue0 = if (nullableValue != null) nullableValue else 0
	println(mustHaveValue0)
	//	Above Two Lines and Below Two Lines Of Code Are Eqivalent
	var mustHaveValue1  = nullableValue ?: 0
	println(mustHaveValue1)

	nullableValue = null
	mustHaveValue0 = nullableValue ?: 0
	println(mustHaveValue0)
}

//_____________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE FLAG!!!

fun playWithCollectionNullability() {
	// Nullability and Collection Types
	// Nullable List Can Store Int Type Data
	// Can't Store null Inside Collection
	var nullableList: List<Int>? = listOf(1, 2, 3, 4)
	println( nullableList?.get(0) )
	nullableList = null
	println(nullableList)
	// Nullable List Can Store Int Type Data
	// Can't Store null Inside Collection
	// var nullableList1: List<Int>? = listOf(1, 2, 3, 4, null, 5)
	// nullableList1 = null
	// println(nullableList1)

	// Non-Nullable List Can Store Int? Type Data 
	// i.e Can Store null Inside Collection
	var listOfNullables: List<Int?> = listOf(1, 2, null, 4)
	// listOfNullables = null // Error: Null can not be a value of a non-null type
	println(listOfNullables)

	// Nullable List Can Store Int? Type Data
	// i.e Can Store null Inside Collection
	var nullableListOfNullables: List<Int?>? = listOf(1, 2, null, 4)
	println( nullableListOfNullables?.get(0) )
	nullableListOfNullables = null
	println(nullableListOfNullables)
}

//_____________________________________________________________________
// DESIGN PRINCIPLE
//		Design Towards Non Nullability Rather Than Nullability
//		Before Introducing Nullability Give Solid Reasoning
//		Handle Nothingness As Early As Possible
//		Resist Temptation To Propogate Nothingness In System

fun playWithNullabilityExperiments() {
	val list1 = listOf(10, 20, 30)
	val list2: List<Int> = listOf(10, 20, 30)
	println(list1)
	println(list2)

	// error: type mismatch: inferred type is List<Int?> but List<Int> was expected
	// val listAgain1: List<Int> = listOf(10, 20, 30, null)

	val listAgain1 = listOf(10, 20, 30, null)
	println(listAgain1)

	var listAgain2: List<Int?> = listOf(10, 20, 30, null)
	println(listAgain1)

	// listAgain2 = null
	var listAgain3: List<Int?>? = listOf(10, 20, 30, null)
	println(listAgain3)

	listAgain3 = null
	println(listAgain3)

	var listAgain4: List<Int>? = listOf(10, 20, 30)
	println(listAgain4)

	// val value1 : Int = listAgain4?.get(0)
	val value1  = listAgain4?.get(0)
	println(value1)

	listAgain4 = null
	println(listAgain4)

	// Handling Nothingness
	val value2 : Int? = listAgain4?.get(0) 
	println(value2)

	val value30 : Int = if ( listAgain4 != null ) listAgain4.get(0) else 0 
	println(value30)

	val value31 : Int = listAgain4?.get(0) ?:  0 
	println(value31)

	var listAgain32: List<Int?>? = listOf(10, 20, 30, null)
	val value32 : Int = listAgain32?.get(3) ?: 999 
	println(value32)
}


//_____________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE FLAG!!!

// Employee Class Having Two Properties
//		name Property Is of String Type And Non Nullable
//		manager Property Is of Employee Type And Nullable
class Employee(val name: String, val manager: Employee?)

fun getManagerName(employee: Employee) : String? {
	//  error: only safe (?.) or non-null asserted (!!.) 
	//  calls are allowed on a nullable receiver of type Employee?
	// return employee.manager.name 
	
	// error: type mismatch: inferred type is String? but String was expected
	
	// If Any Part In Expression Become null Then Whole Expression Becomes null
	// You Cann't Return null From Function, If Return Type Is Non Nullable
	// 		Make Return Type Of Function Nullable, To Return null From Function 
	return employee.manager?.name // ?: "Unknown"
}

fun plaWithEmployeeManager() {
	val ceo 		= Employee("Da Boss", null)
	val ashwaraya 	= Employee("Ashwaraya", ceo)

	println( getManagerName(ashwaraya) )
	println( getManagerName(ceo) )
}

//_____________________________________________________________________
//_____________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE FLAG!!!

// Address Class Have 4 Non Nullable Properties
class Address(
	val streetName: String,
	val zipCode: Int,
	val city: String,
	val country: String
)
// Conpany Class Have 2 Properties
//		name Is NON Nullable Property
//		address Is Nullable Property
class Company( val name: String, val address: Address? )

// Person Class Have 2 Properties
class Person( val name: String, val company: Company? )
//		name Is NON Nullable Property
//		company Is Nullable Property

fun getCountryNameOfPersonCompany(person: Person) : String  {
	// In RHS Expression, If Anything Becomes null 
	// Than Whole RHS Expression Will Becomes Of null Value 

	// error: type mismatch: inferred type is String? but String was expected
	// val country: String = person.company?.address?.country
	val country: String? = person.company?.address?.country

	return if (country != null) country else "Unknown"
}

fun playWithPersonCountry() {
	val alice = Person("Alice", null) 		// company is null
	println( getCountryNameOfPersonCompany(alice) )

	val bobCompany = Company("IBM", null) 	// Company's address is null
	val bob = Person("Bob", bobCompany)
	println( getCountryNameOfPersonCompany(bob) )

	val intelAddress = Address("Outer Ring Road", 560103, "Bangalore", "India")
	val rameshCompany = Company("Intel", intelAddress)
	val rammesh = Person("Bob", rameshCompany)
	println( getCountryNameOfPersonCompany(rammesh) )
}

//_____________________________________________________

class Person2(val firstName: String, val lastName: String) {   
   override fun equals(other: Any?): Boolean {
	  // Explicit Type Casting
   	  //     Use as Keyword For Explicit Type Casting
   		//		Where Type Casting Will Surely Succeed
   	//			Otherwise Use as? Keyword
	  // val otherPerson: Person = other as Person 
	  // val otherPerson: Person? = other as? Person 
	  val otherPerson = other as? Person2 ?: return false

	  return otherPerson.firstName == firstName &&
			 otherPerson.lastName == lastName
   }

   override fun hashCode(): Int =
	  firstName.hashCode() * 37 + lastName.hashCode()
}

fun playWithPersonSafeTypeCast() {
	val p1 = Person2("Dmitry", "Jemerov")
	val p2 = Person2("Dmitry", "Jemerov")
	println(p1 == p2) // p1.equals( p2 )
	println(p1.equals(42))
}

//_____________________________________________________________________

open class Human(val firstName: String, val lastName: String) {
	val fullName = "$firstName $lastName"
}

open class Student(firstName: String, lastName: String) : Human(firstName, lastName)

open class BandMember(firstName: String, lastName: String) : Student(firstName, lastName) {
	open val minimumPracticeTime: Int
		get() { return 2 }
}

class GuitarPlayer(firstName: String, lastName: String) : BandMember(firstName, lastName) {
	override val minimumPracticeTime: Int
		get() { return 4 }
}

fun playWithExplicitTypeCasting() {
	val person : Human = GuitarPlayer("Rishi", "Kapoor")
	println(person.fullName)
	// println(person.minimumPracticeTime)

	val something1 = person as GuitarPlayer 

	println(something1.fullName)
	println(something1.minimumPracticeTime)

	// Compiler Gives Following Warning For next Code Line
	// warning: this cast can never succeed
	// Runtime Error
	// 		Exception in thread "main" java.lang.ClassCastException
	// val something2 = person as Person2
	
	val something2 = person as? Person2

	// println(something2.fullName)
	// println(something.minimumPracticeTime)
}

//_____________________________________________________________________
//_____________________________________________________________________
//_____________________________________________________________________
//_____________________________________________________________________

fun main() {
	println("\nFunction: playWithNullabilityAndNonNullability")
	playWithNullabilityAndNonNullability()

	println("\nFunction: playWithNullabilityAndNonNullabilityAgain")
	playWithNullabilityAndNonNullabilityAgain()

	println("\nFunction: playWithElvisOperator")
	playWithElvisOperator()

	println("\nFunction: playWithCollectionNullability")
	playWithCollectionNullability()

	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
}

/*
https://codebunk.com/b/7631100607916/
https://codebunk.com/b/7631100607916/
https://codebunk.com/b/7631100607916/
*/
