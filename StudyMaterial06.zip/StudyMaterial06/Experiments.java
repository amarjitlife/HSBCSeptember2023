
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;


class SingletonExample {
    //  Class/Type Member
    private static SingletonExample instance =  null;
    // private constructor to avoid client applications using the constructor
    private SingletonExample(){}

    // CLass/Type Member       
    public static SingletonExample getInstance() {
        if ( instance == null )
            instance new SingletonExample();
        return instance;
    }

    public void doDance() { System.out.println("Doing Dance"); }
}

public class Experiments {
    public static void playWithSingleton() {
        SingletonExample singleton = SingletonExample.getInstance();
        singleton.doDance();
    }

    public static void playWithArrayLists() {
        ArrayList<String> friends = new ArrayList<>();
        // friends = null;

        if (friends != null ) friends.add("Peter");
        if (friends != null ) friends.add("Paul");
        if (friends != null ) friends.add("Gabbar");
 
        ArrayList<String> people = friends;

        System.out.println("friends=" + friends);
        System.out.println("people =" + people);

        people.set(0, "Mary");
        
        System.out.println("friends=" + friends);
        System.out.println("people =" + people);

        // for (int i = 0; i < friends.size(); i++) {
        //     System.out.println( friends.get(i) );
        // }

        // for (int i = 0; i < people.size(); i++) {
        //     System.out.println( people.get(i) );
        // }
    }

    public static void main(String[] args) {
    	playWithArrayLists();
    }	
}

