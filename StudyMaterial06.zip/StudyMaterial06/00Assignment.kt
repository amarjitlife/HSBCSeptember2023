___________________________________________________________________________

DAY 01
___________________________________________________________________________

	Assignment A1 : Reading, Thinking Assignment [ MUST MUST ]
		Chapter 05: Pointers and Arrays 				[ THOROUGH READING ]
		Chapter 02: Types, Operators And Expressions 	[ THOROUGH READING ]

		Reference : The C Programming Language, 2nd Edition
			By Brian Kernigham and Dennis Ritchie

	Assignment A2 : Thinking and Experimentation Assignments [ MUST MUST ]
		Already Given It

	Environment E1: Prepare Environment!
		1. Install Android Studio

___________________________________________________________________________

DAY 02
___________________________________________________________________________

	Assignment A1 : Reading, Thinking Assignment [ MUST MUST ]
		Chapter 05: Pointers and Arrays 				[ THOROUGH READING ]
		Chapter 02: Types, Operators And Expressions 	[ THOROUGH READING ]

		Reference : The C Programming Language, 2nd Edition
			By Brian Kernigham and Dennis Ritchie

	Assignment A2 : Revise, Practice and Experimentation Kotlin Code [ MUST MUST ]
		Revise, Practice and Experiment Kotlin Code In Class Till Now

	Assignment A3 : Thinking and Experimentation Assignments [ MUST MUST ]
		Already Given It

	Environment E1: Prepare Environment!
		1. Install Android Studio


___________________________________________________________________________

DAY 03
___________________________________________________________________________

	Assignment A1 : Revise, Practice and Experimentation Kotlin Code [ MUST MUST ]
		Revise, Practice and Experiment Kotlin Code In Class Till Now

	Assignment A2 : Kotlin Reading Assignments [ MUST MUST ]	
		Reference Book: Kotlin In Action By DMITRY JEMEROV AND SVETLANA ISAKOVA
			Chapter 01: Kotlin: What and Why?
			Chapter 02: Kotlin Basics  				[ THOROUGH READING ]
			Chapter 03: Kotlin Defining and Calling Functions 	[ THOROUGH READING ]

	Assignment A3 : REVISE Reading, Thinking Assignment [ MUST MUST ]
		Chapter 05: Pointers and Arrays 				[ THOROUGH READING ]

		Reference : The C Programming Language, 2nd Edition
			By Brian Kernigham and Dennis Ritchie

	Environment E1: Prepare Environment!
		1. Install Android Studio
		2. Tools > SDK Manager

			Install Android SDK 34 With Following Things
				Android Source Code
				Android Platform SDK
				Google Android System Image x86_64 ( Intel Machine )
				Google Android System Image Arm Architecture ( Mac Machine Machine )

___________________________________________________________________________

DAY 04
___________________________________________________________________________

	Assignment A1 : Revise, Practice and Experimentation Kotlin Code [ MUST MUST ]
		Revise, Practice and Experiment Kotlin Code In Class Till Now

	Assignment A2 : Kotlin Reading Assignments [ MUST MUST ]	
		Reference Book: Kotlin In Action By DMITRY JEMEROV AND SVETLANA ISAKOVA
			Chapter 01: Kotlin: What and Why?
			Chapter 02: Kotlin Basics  							[ THOROUGH READING ]
			Chapter 03: Kotlin Defining and Calling Functions 	[ THOROUGH READING ]
			Chapter 06: Higher Order Functions 					[ THOROUGH READING ]

	Environment E1: Prepare Environment!
		1. Install Android Studio
		2. Tools > SDK Manager

			Install Android SDK 34 With Following Things
				Android Source Code
				Android Platform SDK
				Google Android System Image x86_64 ( Intel Machine )
				Google Android System Image Arm Architecture ( Mac Machine Machine )

___________________________________________________________________________

DAY 05
___________________________________________________________________________

	Assignment A1 : Revise, Practice and Experimentation Kotlin Code [ MUST MUST ]
		Revise, Practice and Experiment Kotlin Code In Class Till Now

	Assignment A2 : Kotlin Reading Assignments [ MUST MUST ]	
		Reference Book: Kotlin In Action By DMITRY JEMEROV AND SVETLANA ISAKOVA
			Chapter 01: Kotlin: What and Why?
			Chapter 02: Kotlin Basics  							[ THOROUGH READING ]
			Chapter 03: Kotlin Defining and Calling Functions 	[ THOROUGH READING ]
			Chapter 04: Classes, Objects and Interfaces   		[ THOROUGH READING ]
			Chapter 05: Programming With Lambda  				[ THOROUGH READING ]
			Chapter 06: Kotlin Type Systems  					[ THOROUGH READING ]
			Chapter 08: Higher Order Functions 					[ THOROUGH READING ]

	Environment E1: Prepare Environment!
		1. Install Android Studio
		2. Tools > SDK Manager

			Install Android SDK 34 With Following Things
				Android Source Code
				Android Platform SDK
				Google Android System Image x86_64 ( Intel Machine )
				Google Android System Image Arm Architecture ( Mac Machine Machine )

___________________________________________________________________________

DAY 06
___________________________________________________________________________

	Assignment A1 : Revise, Practice and Experimentation Kotlin Code [ MUST MUST ]
		Revise, Practice and Experiment Kotlin Code In Class Till Now

	Assignment A2 : Kotlin Reading Assignments [ MUST MUST ]	
		Reference Book: Kotlin In Action By DMITRY JEMEROV AND SVETLANA ISAKOVA
			Chapter 01: Kotlin: What and Why?
			Chapter 02: Kotlin Basics  							[ THOROUGH READING ]
			Chapter 03: Kotlin Defining and Calling Functions 	[ THOROUGH READING ]
			Chapter 04: Classes, Objects and Interfaces   		[ THOROUGH READING ]
			Chapter 05: Programming With Lambda  				[ THOROUGH READING ]
			Chapter 06: Kotlin Type Systems  					[ THOROUGH READING ]
			Chapter 07: Opeartor Overloading 					[ THOROUGH READING ]
			Chapter 08: Higher Order Functions 					[ THOROUGH READING ]

	Assignment A2 : Android Reading Assignments [ MUST MUST ]	
		https://developer.android.com/guide/platform


	Environment E1: Prepare Environment!
		1. Install Android Studio
		2. Tools > SDK Manager

		Install Android SDK 34 With Following Things
			Android Source Code
			Android Platform SDK
			Google Android System Image x86_64 ( Intel Machine )
			Google Android System Image Arm Architecture ( Mac Machine Machine )

		Install Android SDK 30 With Following Things
			Android Source Code
			Android Platform SDK
			Google Android System Image x86_64 ( Intel Machine )
			Google Android System Image Arm Architecture ( Mac Machine Machine )
___________________________________________________________________________
___________________________________________________________________________
___________________________________________________________________________
___________________________________________________________________________
___________________________________________________________________________

