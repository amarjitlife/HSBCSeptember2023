/*
Ccmpiling Kotlin File
kotlinc KotlinFunctions.kt -include-runtime -d functions.jar

Running Jar File
java -jar functions.jar
*/

// __________________________________________________
// DO FOLLOWING CODE! MOMENT DONE RAISE YOUR HANDS!!!

fun max(a: Int, b: Int) : Int {
	return if ( a > b ) a else b  
}

fun maximum(a: Int, b: Int) : Int = if ( a > b ) a else b 
fun maximumAgain(a: Int, b: Int)  = if ( a > b ) a else b  

fun playWithMaxFunction() {
	println( max( 100, 200 ) )
	println( max( 300, -300 ) )

	println( maximum( 100, 200 ) )
	println( maximum( 300, -300 ) )

	println( maximumAgain( 100, 200 ) )
	println( maximumAgain( 300, -300 ) )
}

// __________________________________________________
// COMPLETE HANDS ON! MOMENT DONE RAISE YOUR FLAGS!!!

fun getLastCharacter( string: String ) : Char {
	return string.get( string.length - 1 )
}

fun getLastCharacterAgain( string: String ) = string.get( string.length - 1 )

// Extension Functions On Class
//		Used To Add Functionality To Existing Class

// Extension Function On Type String
fun String.lastCharacter() = this.get( this.length - 1 )
	
fun String.doMagic() {
	println("Making String doMagic Using Extension Functions...")
}

fun playWithLastCharacter() {
	println( getLastCharacter( "Good Morning!") )
	println( getLastCharacter( "Flat Number #4409") )

	println( getLastCharacterAgain( "Good Morning!") )
	println( getLastCharacterAgain( "Flat Number #4409") )

	println( "Good Morning!".lastCharacter() )
	println( "Flat Number #4409".lastCharacter() )

	val gabbar = "Gabbar Singh"
	gabbar.doMagic() 
}

// __________________________________________________
// COMPLETE HANDS ON! MOMENT DONE RAISE YOUR FLAGS!!!

fun playWithCollectionIteration() {
	val names = arrayListOf( "Ding", "Dong", "Ting", "Tong")

	// Iterating Over Collection Values
	//		Iterates Over Sequence Of Strings
	for( element in names ) {
		println( element )
	}

	// Iterating Over Collection Tuples Of (Key, Value)
	//		Iteratces Over Sequence of Tuples
	for( something in names.withIndex() ) {
		println( something )
	}

	// Iterating Over Collection Tuples Of (Key, Value)
	//		And Unpacking/Decluttering/Deconstrcuting Over index And element
	for( (index, element) in names.withIndex() ) {
		println("At Index: $index Value: $element" )
	}
}

// __________________________________________________
// COMPLETE HANDS ON! MOMENT DONE RAISE YOUR FLAGS!!!

fun joinToString(
	collection: ArrayList<String>,
	seperator: String,
	prefix: String,
	postfix: String
) : String {
	val result = StringBuilder( prefix )

	for( (index, element) in collection.withIndex() ) {
		if ( index > 0 ) result.append( seperator )
		result.append( element )
	}
	result.append( postfix )
	return result.toString()
}

fun playWithJoinToString() {
	val names = arrayListOf("Ting", "Tong", "Zing", "Zong", "Ding", "Dong", )

	val something = joinToString( names, " , ", " ( ", " ) ")
	println( something )

	val somethingAgain = joinToString( names, " #### ", " [[[ ", " ]]] ")
	println( somethingAgain )
}

// __________________________________________________
// COMPLETE HANDS ON! MOMENT DONE RAISE YOUR FLAGS!!!
// Polymporphic Function
//		Mechanism:  Using Argumemnts with Default Values
//					 Default Arguments

fun joinToStringAgain(
	collection: ArrayList<String>,
	seperator: String = " ", // Initialising With Default Values
	prefix: String = "",
	postfix: String = ""
) : String {
	val result = StringBuilder( prefix )

	for( (index, element) in collection.withIndex() ) {
		if ( index > 0 ) result.append( seperator )
		result.append( element )
	}
	result.append( postfix )
	return result.toString()
}

fun playWithJoinToStringAgain() {
	val names = arrayListOf("Ting", "Tong", "Zing", "Zong", "Ding", "Dong", )

	var something: String
	something = joinToStringAgain( names )
	println( something )
	something = joinToStringAgain( names, " , " ) 
	println( something )
	something = joinToStringAgain( names, " , " , " ( ") 
	println( something )
	something = joinToStringAgain( names, " , ", " ( ", " ) ")
	println( something )

	var somethingAgain: String
	somethingAgain = joinToStringAgain( names )
	println( somethingAgain )
	somethingAgain = joinToStringAgain( names, " #### " )
	println( somethingAgain )
	somethingAgain = joinToStringAgain( names, " #### ", " [[[ " )
	println( somethingAgain )
	somethingAgain = joinToStringAgain( names, " #### ", " [[[ ", " ]]] " )
	println( somethingAgain )
}

// __________________________________________________
// COMPLETE HANDS ON! MOMENT DONE RAISE YOUR FLAGS!!!

fun ArrayList<String>.joinToStringExtension(
	// collection: ArrayList<String>,
	seperator: String = " ", // Initialising With Default Values
	prefix: String = "",
	postfix: String = ""
) : String {
	val result = StringBuilder( prefix )

	for( (index, element) in this.withIndex() ) {
		if ( index > 0 ) result.append( seperator )
		result.append( element )
	}
	result.append( postfix )
	return result.toString()
}

fun playWithJoinToStringExtension() {
	val names = arrayListOf("Ting", "Tong", "Zing", "Zong", "Ding", "Dong", )

	var something: String
	something = names.joinToStringExtension( )
	println( something )
	something = names.joinToStringExtension( " , " ) 
	println( something )
	something = names.joinToStringExtension( " , " , " ( ") 
	println( something )
	something = names.joinToStringExtension( " , ", " ( ", " ) ")
	println( something )

	var somethingAgain: String
	somethingAgain = names.joinToStringExtension( )
	println( somethingAgain )
	somethingAgain = names.joinToStringExtension( " #### " )
	println( somethingAgain )
	somethingAgain = names.joinToStringExtension( " #### ", " [[[ " )
	println( somethingAgain )
	somethingAgain = names.joinToStringExtension( " #### ", " [[[ ", " ]]] " )
	println( somethingAgain )
}

// __________________________________________________
// COMPLETE HANDS ON! MOMENT DONE RAISE YOUR FLAGS!!!

// Extension Properties On Class
//		Properties Added In Class Using Extension Syntax

// lastChar Is Extension Propetty On Class/Type String
//		It's Immutbale Extension Property
val String.lastChar : Char
	get() { // Custom Getter Defined By Programmer
		return this.get( length - 1)
	}

// lastChar Is Extension Propetty On Class/Type StringBuilder
//		It's Mutbale Extension Property
var StringBuilder.lastChar : Char
	// get() { // Custom Getter Defined By The Programmer
	// 		error: a 'return' expression required in a function with a block body ('{...}')
	// 		this.get( length - 1 ) 
	// 	   	return this.get( length - 1 ) 
	// }

	// Following Both Definition Of Getter Are Same
	// get() = this.get( this.length - 1 ) 
	get() = get( length - 1 ) 

	set( value: Char ) { // Custom Setter Defined By The Programmer
		this.setCharAt( length - 1, value )
	}

fun playWithExtensionProperties() {
	println( "Good Morning!".lastChar )
	println( "Flat Number #4409".lastChar )

	var sb = StringBuilder( "How are you doing?" )
	println( sb )
	println( sb.lastChar )
	sb.lastChar = '#'
	println( sb )
	println( sb.lastChar )
}

// __________________________________________________
// COMPLETE HANDS ON! MOMENT DONE RAISE YOUR FLAGS!!!

// DESIGN PRINCIPLE
//		DESIGN TOWARDS IMMUTABILITY RATHER THAN MUTABILITY
//		USE MUTABILITY ONLY WHEN IT'S REQUIRED
class User( val id: Int, val name: String, val address: String )

fun saveUser( user: User ) {
	// Validation Of User Data
	if ( user.name.isEmpty() ) {
		throw IllegalArgumentException("Can't Save User : ${ user.id } Name Is Empty")
	}

	if ( user.address.isEmpty() ) {
		throw IllegalArgumentException("Can't Save User : ${ user.id } Address Is Empty")
	}	
	// Save User In Database...
	saveUserInDatabase( user )
}

fun saveUserInDatabase( user: User ) {
	println("Saving User ${user.id} In Database...")	
} 

fun playWithSaveUserFunction() {
	val gabbar 	= User( 420, "Gabbar Singh", "Ramgarh" )
	val samba  	= User( 120, "Samba", "Ramgarh")
	val basanti = User( 100, "Basanti", "Thakur's Village")

	saveUser( gabbar )
	saveUser( samba )
	saveUser( basanti )
}

// __________________________________________________
// COMPLETE HANDS ON! MOMENT DONE RAISE YOUR FLAGS!!!

// class User( val id: Int, val name: String, val address: String )
fun saveUserAgain( user: User ) {
	// Local Function
	//		Function Defined Inside A Function
	//		Can't Be Directly Accessed Outside Function By Default
	fun validate( user: User, value: String, fieldName: String ) {
		if ( value.isEmpty() ) {
			throw IllegalArgumentException("Can't Save User: For ${ user.id } = $fieldName Empty!")
		}
	}

	fun saveUserInDatabase( user: User ) {
		println("Local Function: Saving User ${user.id} In Database...")	
	} 
	// Validation Of User Data
	validate( user, user.name, "Name" )
	validate( user, user.address, "Address" )

	// Save User In Database...
	saveUserInDatabase( user )
}

fun playWithSaveUserAgainFunction() {
	val gabbar 	= User( 420, "Gabbar Singh", "Ramgarh" )
	val samba  	= User( 120, "Samba", "Ramgarh")
	val basanti = User( 100, "Basanti", "Thakur's Village")

	saveUserAgain( gabbar )
	saveUserAgain( samba )
	saveUserAgain( basanti )
}

// __________________________________________________
// __________________________________________________
// __________________________________________________
// __________________________________________________
// COMPLETE HANDS ON! MOMENT DONE RAISE YOUR FLAGS!!!

fun main() {
	println("\nFunction: playWithMaxFunction")
	playWithMaxFunction()

	println("\nFunction: playWithLastCharacter")
	playWithLastCharacter()

	println("\nFunction: playWithCollectionIteration")
	playWithCollectionIteration()

	println("\nFunction: playWithJoinToString")
	playWithJoinToString()

	println("\nFunction: playWithJoinToStringAgain")
	playWithJoinToStringAgain()

	println("\nFunction: playWithJoinToStringExtension")
	playWithJoinToStringExtension()

	println("\nFunction: playWithExtensionProperties")
	playWithExtensionProperties()

	println("\nFunction: playWithSaveUserFunction")
	playWithSaveUserFunction()

	println("\nFunction: playWithSaveUserAgainFunction")
	playWithSaveUserAgainFunction()

	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
}

/*
	https://codebunk.com/b/6251100617995/
	https://codebunk.com/b/6251100617995/
	https://codebunk.com/b/6251100617995/
*/
